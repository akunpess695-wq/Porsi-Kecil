package com.porsikecil.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.porsikecil.app.R
import com.porsikecil.app.data.DayNames
import com.porsikecil.app.data.MealTypes
import com.porsikecil.app.data.PlanEntry
import com.porsikecil.app.data.Recipe
import com.porsikecil.app.data.Recipes
import com.porsikecil.app.data.ShoppingItem
import com.porsikecil.app.data.allergens
import com.porsikecil.app.data.buildShoppingFromPlan
import com.porsikecil.app.data.mergeShopping
import com.porsikecil.app.data.newId
import com.porsikecil.app.data.weekStart
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Space
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/*
 * Planner (Tahap 4a). Hanya perubahan tampilan dan interaksi UI. data/Planner.kt dan tes tidak diubah.
 * Jadwal = saran, bukan kewajiban; semua teks keselamatan lama dipertahankan.
 */

@Composable
fun PlannerScreen(
    stageMonths: Int,
    avoid: Set<String>,
    plan: List<PlanEntry>,
    onPlanChange: (List<PlanEntry>) -> Unit,
    shopping: List<ShoppingItem>,
    onShoppingChange: (List<ShoppingItem>) -> Unit
) {
    var section by remember { mutableStateOf("Jadwal") }
    var weekOffset by remember { mutableIntStateOf(0) }
    val start = weekStart(LocalDate.now()).plusWeeks(weekOffset.toLong())

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    // Nilai terbaru, dipakai saat "Urungkan" ditekan beberapa detik setelah menghapus.
    val latestPlan by rememberUpdatedState(plan)
    val latestShopping by rememberUpdatedState(shopping)

    val removePlanEntry: (PlanEntry) -> Unit = { e ->
        onPlanChange(latestPlan.filter { it.id != e.id })
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar(
                message = "Menu dihapus: ${e.title}",
                actionLabel = "Urungkan",
                duration = SnackbarDuration.Long
            )
            if (r == SnackbarResult.ActionPerformed) onPlanChange(latestPlan + e)
        }
    }
    val removeShoppingItem: (ShoppingItem) -> Unit = { item ->
        onShoppingChange(latestShopping.filter { it.id != item.id })
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar(
                message = "Item dihapus: ${item.name}",
                actionLabel = "Urungkan",
                duration = SnackbarDuration.Long
            )
            if (r == SnackbarResult.ActionPerformed) onShoppingChange(latestShopping + item)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = Space.screen, vertical = Space.l),
            verticalArrangement = Arrangement.spacedBy(Space.m)
        ) {
            SectionHeader("Planner")
            ChipRow(listOf("Jadwal", "Belanja"), section) { section = it }
            WeekHeader(
                start = start,
                isCurrentWeek = weekOffset == 0,
                onPrev = { weekOffset -= 1 },
                onNext = { weekOffset += 1 },
                onToday = { weekOffset = 0 }
            )
            if (section == "Jadwal") {
                WeekPlan(
                    stageMonths = stageMonths,
                    avoid = avoid,
                    start = start,
                    plan = plan,
                    onAdd = { entry -> onPlanChange(latestPlan + entry) },
                    onRemove = removePlanEntry,
                    modifier = Modifier.weight(1f)
                )
            } else {
                ShoppingSection(
                    start = start,
                    plan = plan,
                    shopping = shopping,
                    onChange = onShoppingChange,
                    onRemoveItem = removeShoppingItem,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
    }
}

private fun dateFormatter(): DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("id-ID"))

@Composable
private fun WeekHeader(
    start: LocalDate,
    isCurrentWeek: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onToday: () -> Unit
) {
    val f = remember { dateFormatter() }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onPrev) {
            Icon(painterResource(R.drawable.ic_back), contentDescription = "Minggu sebelumnya")
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "${start.format(f)} – ${start.plusDays(6).format(f)}",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium
            )
            if (isCurrentWeek) {
                Text(
                    "Minggu ini",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                TextButton(onClick = onToday, modifier = Modifier.heightIn(min = Space.touch)) {
                    Text("Kembali ke minggu ini")
                }
            }
        }
        IconButton(onClick = onNext) {
            Icon(
                painterResource(R.drawable.ic_back),
                contentDescription = "Minggu berikutnya",
                modifier = Modifier.rotate(180f)
            )
        }
    }
}

/** Penanda alergen yang dihindari: ikon + teks (tidak hanya warna). Tidak memblokir pilihan. */
@Composable
private fun AllergenWarning(hit: List<String>) {
    Row(
        Modifier
            .clip(MaterialTheme.shapes.small)
            .background(Peach)
            .padding(horizontal = Space.s, vertical = Space.xs),
        horizontalArrangement = Arrangement.spacedBy(Space.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Warning, contentDescription = null, tint = Ink, modifier = Modifier.size(16.dp))
        Text(
            "Perhatian: mengandung ${hit.joinToString(", ")} (Anda hindari)",
            style = MaterialTheme.typography.labelMedium,
            color = Ink
        )
    }
}

@Composable
private fun WeekPlan(
    stageMonths: Int,
    avoid: Set<String>,
    start: LocalDate,
    plan: List<PlanEntry>,
    onAdd: (PlanEntry) -> Unit,
    onRemove: (PlanEntry) -> Unit,
    modifier: Modifier
) {
    var addForDay by remember { mutableStateOf<LocalDate?>(null) }
    val f = remember { dateFormatter() }
    val todayDate = LocalDate.now()
    val startDay = start.toEpochDay()
    val weekIsEmpty = plan.none { it.epochDay >= startDay && it.epochDay <= startDay + 6 }

    // LazyColumn: thumbnail resep hanya didekode untuk kartu yang terlihat.
    LazyColumn(
        modifier,
        verticalArrangement = Arrangement.spacedBy(Space.m),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = Space.xl)
    ) {
        if (weekIsEmpty) {
            item {
                EmptyState(
                    art = R.drawable.ill_empty_bowl,
                    title = "Belum ada menu minggu ini",
                    body = "Tambahkan menu di tiap hari. Jadwal ini hanya saran dan bisa diubah kapan saja."
                )
            }
        }
        items(7) { i ->
            val date = start.plusDays(i.toLong())
            val dayItems = plan
                .filter { it.epochDay == date.toEpochDay() }
                .sortedBy { MealTypes.indexOf(it.meal) }
            val isToday = date == todayDate
            PkCard(color = if (isToday) Mint else Color.White) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${DayNames[i]}, ${date.format(f)}",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (isToday) MetaPill("Hari ini", container = Color.White)
                }
                dayItems.forEach { e ->
                    PlanEntryRow(e, avoid, onRemove)
                }
                TextButton(
                    onClick = { addForDay = date },
                    modifier = Modifier
                        .heightIn(min = Space.touch)
                        .semantics { contentDescription = "Tambah menu hari ${DayNames[i]}" }
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Space.xs))
                    Text("Tambah menu")
                }
            }
        }
    }

    val day = addForDay
    if (day != null) {
        AddPlanDialog(
            date = day,
            stageMonths = stageMonths,
            avoid = avoid,
            onDismiss = { addForDay = null },
            onSave = { entry ->
                onAdd(entry)
                addForDay = null
            }
        )
    }
}

@Composable
private fun PlanEntryRow(e: PlanEntry, avoid: Set<String>, onRemove: (PlanEntry) -> Unit) {
    val recipe = remember(e.recipeId) { Recipes.firstOrNull { it.id == e.recipeId } }
    val hit = recipe?.allergens?.filter { it in avoid }.orEmpty()
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(Space.m),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (recipe != null) {
            // Dekoratif: judul menu sudah dibaca di teks.
            RecipeImage(recipeArt(recipe).copy(description = ""), Modifier.width(64.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.xs)) {
            Text(
                e.meal,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(e.title, style = MaterialTheme.typography.bodyLarge)
            if (hit.isNotEmpty()) AllergenWarning(hit)
        }
        TextButton(
            onClick = { onRemove(e) },
            modifier = Modifier
                .heightIn(min = Space.touch)
                .semantics { contentDescription = "Hapus ${e.meal}: ${e.title}" }
        ) { Text("Hapus") }
    }
}

@Composable
private fun RecipeChoiceRow(recipe: Recipe, selected: Boolean, hit: List<String>, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = Space.touch)
            .clip(MaterialTheme.shapes.medium)
            .background(if (selected) Mint else Color.Transparent)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(Space.s),
        horizontalArrangement = Arrangement.spacedBy(Space.m),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RecipeImage(recipeArt(recipe).copy(description = ""), Modifier.width(64.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.xs)) {
            Text(
                recipe.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
            if (hit.isNotEmpty()) AllergenWarning(hit)
        }
        if (selected) {
            Icon(
                painterResource(R.drawable.ic_check),
                contentDescription = "Dipilih",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun AddPlanDialog(
    date: LocalDate,
    stageMonths: Int,
    avoid: Set<String>,
    onDismiss: () -> Unit,
    onSave: (PlanEntry) -> Unit
) {
    var meal by remember { mutableStateOf(MealTypes[0]) }
    var mode by remember { mutableStateOf("Pilih resep") }
    var selectedId by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }
    val pool = remember(stageMonths) { Recipes.filter { it.minMonths <= stageMonths }.ifEmpty { Recipes } }
    val f = remember { dateFormatter() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah menu, ${DayNames[date.dayOfWeek.value - 1]} ${date.format(f)}") },
        text = {
            // LazyColumn: hanya baris yang terlihat yang memuat gambar.
            LazyColumn(
                Modifier.heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(Space.s)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(Space.s)) {
                        Text("Waktu makan", style = MaterialTheme.typography.labelLarge)
                        ChipRow(MealTypes, meal) { meal = it }
                        ChipRow(listOf("Pilih resep", "Tulis sendiri"), mode) { mode = it }
                    }
                }
                if (mode == "Pilih resep") {
                    if (stageMonths < 6) {
                        item {
                            Text(
                                "Si kecil belum 6 bulan. Jadwal ini hanya untuk persiapan, mulai MPASI sesuai arahan dokter anak.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    items(pool, key = { it.id }) { r ->
                        RecipeChoiceRow(
                            recipe = r,
                            selected = r.id == selectedId,
                            hit = r.allergens.filter { it in avoid },
                            onClick = { selectedId = r.id }
                        )
                    }
                } else {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(Space.s)) {
                            OutlinedTextField(
                                value = custom,
                                onValueChange = { custom = it.take(60) },
                                label = { Text("Nama menu") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                "Menu tulis sendiri tidak punya daftar bahan, jadi tidak ikut masuk daftar belanja.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            val canSave = if (mode == "Pilih resep") selectedId.isNotEmpty() else custom.isNotBlank()
            TextButton(
                enabled = canSave,
                onClick = {
                    val recipe = Recipes.firstOrNull { it.id == selectedId }
                    val useRecipe = mode == "Pilih resep" && recipe != null
                    onSave(
                        PlanEntry(
                            id = newId(),
                            epochDay = date.toEpochDay(),
                            meal = meal,
                            recipeId = if (useRecipe) selectedId else "",
                            title = if (useRecipe && recipe != null) recipe.title else custom.trim()
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
private fun ShoppingSection(
    start: LocalDate,
    plan: List<PlanEntry>,
    shopping: List<ShoppingItem>,
    onChange: (List<ShoppingItem>) -> Unit,
    onRemoveItem: (ShoppingItem) -> Unit,
    modifier: Modifier
) {
    var showAdd by remember { mutableStateOf(false) }
    var confirmRegenerate by remember { mutableStateOf(false) }
    var confirmClearChecked by remember { mutableStateOf(false) }
    val startDay = start.toEpochDay()
    val weekEntries = plan.filter { it.epochDay >= startDay && it.epochDay <= startDay + 6 }
    val hasCustomMenu = weekEntries.any { it.recipeId.isBlank() }
    val sorted = shopping.sortedBy { it.checked }
    val remaining = shopping.count { !it.checked }
    val checkedCount = shopping.count { it.checked }

    fun regenerate() {
        onChange(mergeShopping(shopping, buildShoppingFromPlan(weekEntries)))
    }

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(Space.m)
    ) {
        Text(
            "Daftar dibuat dari bahan resep di jadwal minggu yang dipilih. Centang bahan yang sudah ada di rumah atau sudah dibeli.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (hasCustomMenu) {
            InfoNote("Menu tulis sendiri tidak punya daftar bahan, jadi tidak ikut masuk daftar belanja.")
        }
        Button(
            onClick = {
                if (shopping.any { it.auto }) confirmRegenerate = true else regenerate()
            },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = Space.touch)
        ) { Text("Buat dari jadwal minggu ini") }

        Row(horizontalArrangement = Arrangement.spacedBy(Space.s), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.heightIn(min = Space.touch)) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(Space.xs))
                Text("Tambah item")
            }
            TextButton(
                enabled = checkedCount > 0,
                onClick = { confirmClearChecked = true },
                modifier = Modifier.heightIn(min = Space.touch)
            ) { Text("Hapus yang dicentang") }
        }

        if (shopping.isEmpty()) {
            EmptyState(
                art = R.drawable.ill_empty_bowl,
                title = "Daftar masih kosong",
                body = "Tambahkan resep ke jadwal, lalu tekan tombol di atas. Anda juga bisa menambah item sendiri."
            )
        } else {
            Text("Belum dibeli: $remaining dari ${shopping.size}", style = MaterialTheme.typography.titleMedium)
            sorted.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = item.checked,
                        onCheckedChange = { c ->
                            onChange(shopping.map { if (it.id == item.id) it.copy(checked = c) else it })
                        }
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            item.name,
                            fontWeight = FontWeight.SemiBold,
                            textDecoration = if (item.checked) TextDecoration.LineThrough else TextDecoration.None
                        )
                        if (item.amount.isNotBlank()) {
                            Text(
                                item.amount,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    TextButton(
                        onClick = { onRemoveItem(item) },
                        modifier = Modifier
                            .heightIn(min = Space.touch)
                            .semantics { contentDescription = "Hapus ${item.name}" }
                    ) { Text("Hapus") }
                }
            }
        }
    }

    if (showAdd) {
        AddShoppingDialog(
            onDismiss = { showAdd = false },
            onSave = { item ->
                onChange(shopping + item)
                showAdd = false
            }
        )
    }

    if (confirmRegenerate) {
        AlertDialog(
            onDismissRequest = { confirmRegenerate = false },
            title = { Text("Ganti daftar otomatis?") },
            text = {
                Text(
                    "Item yang dibuat otomatis sebelumnya, termasuk dari minggu lain, akan diganti dengan bahan dari jadwal minggu ini. " +
                        "Item yang Anda tambah sendiri tetap ada. Centang dipertahankan bila nama bahannya sama."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    regenerate()
                    confirmRegenerate = false
                }) { Text("Ganti") }
            },
            dismissButton = {
                TextButton(onClick = { confirmRegenerate = false }) { Text("Batal") }
            }
        )
    }

    if (confirmClearChecked) {
        AlertDialog(
            onDismissRequest = { confirmClearChecked = false },
            title = { Text("Hapus $checkedCount item yang dicentang?") },
            text = { Text("Item yang dihapus tidak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = {
                    onChange(shopping.filter { !it.checked })
                    confirmClearChecked = false
                }) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearChecked = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun AddShoppingDialog(onDismiss: () -> Unit, onSave: (ShoppingItem) -> Unit) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah item belanja") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(Space.s)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Nama bahan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.take(30) },
                    label = { Text("Jumlah (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        ShoppingItem(
                            id = newId(),
                            name = name.trim(),
                            amount = amount.trim(),
                            checked = false,
                            auto = false
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
