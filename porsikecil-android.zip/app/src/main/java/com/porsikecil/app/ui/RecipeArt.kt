package com.porsikecil.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.porsikecil.app.R
import com.porsikecil.app.data.Recipe
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky

/** Ilustrasi + warna latar + deskripsi TalkBack untuk satu resep. Murni UI; tidak mengubah data resep. */
data class RecipeArtSpec(@DrawableRes val res: Int, val tint: Color, val description: String)

/**
 * Pemetaan id resep -> gambar lokal (PNG/WebP 1024x768 di drawable-nodpi), dicocokkan lewat [Recipe.id],
 * bukan urutan daftar. Resep dengan id yang belum dikenal memakai mangkuk (placeholder konsisten).
 * Sebagian gambar ilustrasi, sebagian foto hasil generasi AI (jangan disebut "foto asli" di UI/Play Store); bisa diganti per file tanpa mengubah id resep atau pemanggil.
 */
fun recipeArt(r: Recipe): RecipeArtSpec = when (r.id) {
    "puree-kentang-wortel" -> RecipeArtSpec(R.drawable.recipe_puree_kentang_wortel, Peach, "Puree kentang wortel")
    "puree-alpukat-pisang" -> RecipeArtSpec(R.drawable.recipe_puree_alpukat_pisang, Mint, "Puree alpukat pisang")
    "puree-ubi-labu" -> RecipeArtSpec(R.drawable.recipe_puree_ubi_labu, Butter, "Puree ubi labu")
    "bubur-ayam-wortel" -> RecipeArtSpec(R.drawable.recipe_bubur_ayam_wortel, Butter, "Bubur ayam wortel saring")
    "okayu-bayi" -> RecipeArtSpec(R.drawable.recipe_okayu_bayi, Butter, "Bubur nasi lembut polos")
    "tahu-labu-lembut" -> RecipeArtSpec(R.drawable.recipe_tahu_labu_lembut, Butter, "Tahu labu kuning lembut")
    "bubur-hati-bayam" -> RecipeArtSpec(R.drawable.recipe_bubur_hati_bayam, Mint, "Bubur hati ayam bayam")
    "bubur-tempe-bayam" -> RecipeArtSpec(R.drawable.recipe_bubur_tempe_bayam, Mint, "Bubur tempe bayam")
    "bubur-ikan-brokoli" -> RecipeArtSpec(R.drawable.recipe_bubur_ikan_brokoli, Sky, "Bubur ikan brokoli")
    "bubur-ikan-bayam" -> RecipeArtSpec(R.drawable.recipe_bubur_ikan_bayam, Mint, "Bubur nasi ikan dan bayam")
    "puree-daging-brokoli" -> RecipeArtSpec(R.drawable.recipe_puree_daging_brokoli, Peach, "Puree daging sapi brokoli")
    "puree-salmon-wortel" -> RecipeArtSpec(R.drawable.recipe_puree_salmon_wortel, Peach, "Puree salmon wortel")
    "puree-telur-brokoli" -> RecipeArtSpec(R.drawable.recipe_puree_telur_brokoli, Butter, "Puree telur brokoli")
    "tim-daging-tomat" -> RecipeArtSpec(R.drawable.recipe_tim_daging_tomat, Peach, "Tim daging tomat")
    "telur-orak-arik" -> RecipeArtSpec(R.drawable.recipe_telur_orak_arik, Butter, "Telur orak-arik dan nasi tim")
    "telur-kukus-lembut" -> RecipeArtSpec(R.drawable.recipe_telur_kukus_lembut, Butter, "Telur kukus lembut wortel")
    "tim-salmon-labu" -> RecipeArtSpec(R.drawable.recipe_tim_salmon_labu, Peach, "Tim salmon labu")
    "perkedel-tahu-wortel" -> RecipeArtSpec(R.drawable.recipe_perkedel_tahu_wortel, Peach, "Perkedel tahu wortel")
    "pancake-pisang-oat" -> RecipeArtSpec(R.drawable.recipe_pancake_pisang_oat, Butter, "Pancake pisang oat")
    "nasi-tim-ayam-jamur" -> RecipeArtSpec(R.drawable.recipe_nasi_tim_ayam_jamur, Butter, "Nasi tim ayam jamur")
    "sup-ayam-sayur" -> RecipeArtSpec(R.drawable.recipe_sup_ayam_sayur, Mint, "Sup ayam sayur")
    else -> RecipeArtSpec(R.drawable.ill_bowl, Mint, "Ilustrasi mangkuk makanan")
}

/** True untuk gambar adegan penuh 4:3 (PNG resep); false untuk placeholder mangkuk vektor. */
fun RecipeArtSpec.isFullScene(): Boolean = res != R.drawable.ill_bowl

/** Ilustrasi untuk satu bahan di daftar Bahan. Bahan tanpa ilustrasi khusus memakai mangkuk. */
fun foodArt(f: com.porsikecil.app.data.FoodItem): RecipeArtSpec = when (f.name) {
    "Kentang", "Ubi jalar" -> RecipeArtSpec(R.drawable.ill_potato, Peach, "Ilustrasi kentang")
    "Alpukat" -> RecipeArtSpec(R.drawable.ill_avocado, Mint, "Ilustrasi alpukat")
    "Wortel" -> RecipeArtSpec(R.drawable.ill_carrot, Peach, "Ilustrasi wortel")
    "Brokoli" -> RecipeArtSpec(R.drawable.ill_broccoli, Mint, "Ilustrasi brokoli")
    "Labu kuning" -> RecipeArtSpec(R.drawable.ill_pumpkin, Butter, "Ilustrasi labu")
    "Telur" -> RecipeArtSpec(R.drawable.ill_egg, Butter, "Ilustrasi telur")
    "Ikan kembung", "Ikan salmon" -> RecipeArtSpec(R.drawable.ill_fish, Sky, "Ilustrasi ikan")
    else -> RecipeArtSpec(R.drawable.ill_bowl, Mint, "Ilustrasi mangkuk makanan")
}
