package com.porsikecil.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.porsikecil.app.R
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Space

/*
 * Tab Profil (Tahap 4c). Hanya tampilan: tidak ada tombol ekspor/hapus data karena fungsinya belum dibuat.
 * Teks privasi dan batasan dipertahankan kata per kata.
 */
@Composable
fun ProfileTab(
    profile: BabyProfile,
    avoid: Set<String>,
    favoriteCount: Int,
    onEditProfile: () -> Unit,
    onOpenJournal: () -> Unit,
    onOpenRecipes: () -> Unit
) {
    val age = remember(profile) { calculateAge(profile) }
    val weeks = profile.gestationWeeks
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Space.screen, vertical = Space.l),
        verticalArrangement = Arrangement.spacedBy(Space.m)
    ) {
        SectionHeader("Profil")

        PkCard(color = Peach) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Space.l),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IllustrationTile(
                    res = R.drawable.ill_hero_baby,
                    contentDescription = null, // dekoratif; nama bayi dibaca di teks
                    background = Color.White
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                    Text(profile.name, style = MaterialTheme.typography.titleLarge)
                    Text("Usia: ${age.chronoText}")
                    if (age.correctedText != null) {
                        Text("Usia koreksi: ${age.correctedText}")
                    }
                }
            }
            if (weeks != null) {
                MetaPill("Lahir prematur, $weeks minggu")
            }
            OutlinedButton(
                onClick = onEditProfile,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = Space.touch)
            ) { Text("Ubah profil") }
        }

        PkCard {
            Text("Preferensi", style = MaterialTheme.typography.titleMedium)
            Text(
                if (avoid.isEmpty()) "Alergen yang dihindari: belum ada"
                else "Alergen yang dihindari: ${avoid.sorted().joinToString(", ")}"
            )
            Text("Resep favorit: $favoriteCount")
            Text(
                "Daftar alergen diatur dari filter alergen di tab Resep. Ini catatan Anda, bukan hasil diagnosis.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            TextButton(onClick = onOpenRecipes, modifier = Modifier.heightIn(min = Space.touch)) {
                Text("Buka tab Resep")
            }
        }

        PkCard(color = Mint) {
            Text("Jurnal makanan", style = MaterialTheme.typography.titleMedium)
            Text("Catatan menu, porsi, dan respons si kecil.")
            TextButton(onClick = onOpenJournal, modifier = Modifier.heightIn(min = Space.touch)) {
                Text("Buka jurnal")
            }
        }

        PkCard(color = Butter) {
            Text("Privasi dan batasan", style = MaterialTheme.typography.titleMedium)
            Text("• Data tersimpan hanya di perangkat ini dan tidak dikirim ke server.")
            Text("• Cadangan otomatis Android dimatikan untuk melindungi data bayi.")
            Text("• Aplikasi ini bukan alat diagnosis dan bukan pengganti dokter anak atau ahli gizi.")
        }
    }
}
