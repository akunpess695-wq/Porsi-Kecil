package com.porsikecil.app.data

import android.content.Context
import java.time.LocalDate

/** gestationWeeks null = lahir cukup bulan. */
data class BabyProfile(
    val name: String,
    val birthDate: LocalDate,
    val gestationWeeks: Int?
)

class BabyRepository(context: Context) {
    private val prefs = context.getSharedPreferences("porsikecil", Context.MODE_PRIVATE)

    fun load(): BabyProfile? {
        val name = prefs.getString("name", null) ?: return null
        val day = prefs.getLong("birth_day", Long.MIN_VALUE)
        if (day == Long.MIN_VALUE) return null
        val weeks = prefs.getInt("gestation_weeks", 0)
        return BabyProfile(
            name = name,
            birthDate = LocalDate.ofEpochDay(day),
            gestationWeeks = if (weeks in 20..36) weeks else null
        )
    }

    fun save(p: BabyProfile) {
        prefs.edit()
            .putString("name", p.name)
            .putLong("birth_day", p.birthDate.toEpochDay())
            .putInt("gestation_weeks", p.gestationWeeks ?: 0)
            .apply()
    }

    fun onboardingDone(): Boolean = prefs.getBoolean("onboarding_done", false)

    fun setOnboardingDone() {
        prefs.edit().putBoolean("onboarding_done", true).apply()
    }
}
