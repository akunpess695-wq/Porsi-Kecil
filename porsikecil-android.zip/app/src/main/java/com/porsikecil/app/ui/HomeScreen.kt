package com.porsikecil.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.porsikecil.app.R
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.JournalEntry
import com.porsikecil.app.data.MealTypes
import com.porsikecil.app.data.PlanEntry
import com.porsikecil.app.data.ReactionAllergy
import com.porsikecil.app.data.Recipes
import com.porsikecil.app.data.allergenSummary
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.data.distinctFoodCount
import com.porsikecil.app.data.recipeOfTheDay
import com.porsikecil.app.data.stageFor
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Paper
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky
import com.porsikecil.app.ui.theme.Space
import java.time.LocalDate

// Teks peringatan prematur. Kata-katanya tidak boleh diubah (teks keselamatan).
private const val PrematureWarning =
    "Si kecil lahir prematur. Panduan umum di aplikasi ini mungkin tidak sesuai. " +
        "Tahap, tekstur, dan frekuensi makan sebaiknya ditentukan bersama dokter atau ahli gizi anak."

/**
 * Beranda (Tahap 2). Urutan: sapaan, peringatan prematur (bila ada), hero tahap makan,
 * menu hari ini, ringkasan jurnal, pintasan, pengingat keamanan. Detail frekuensi/sumber
 * dipindah ke sheet "Lihat panduan"; tidak ada teks yang dihapus.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    profile: BabyProfile,
    avoid: Set<String>,
    entries: List<JournalEntry>,
    plan: List<PlanEntry>,
    onEditProfile: () -> Unit,
    onOpenRecipes: () -> Unit,
    onOpenPlanner: () -> Unit,
    onOpenJournal: () -> Unit,
    onOpenEducation: () -> Unit
) {
    val age = remember(profile) { calculateAge(profile) }
    val stage = stageFor(age.stageMonths)
    val todayDate = LocalDate.now()
    val today = todayDate.toEpochDay()
    val todayCount = entries.count { it.epochDay == today }
    val foodCount = distinctFoodCount(entries)
    val recentAllergy = entries.any { it.reaction == ReactionAllergy && it.epochDay >= today - 7 }
    val menu = recipeOfTheDay(age.stageMonths, todayDate, avoid)
    val todayPlan = plan.filter { it.epochDay == today }.sortedBy { MealTypes.indexOf(it.meal) }
    var showGuide by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = Space.screen, vertical = Space.l),
        verticalArrangement = Arrangement.spacedBy(Space.l)
    ) {
        // 1. Sapaan + tombol profil
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Halo,",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    profile.name,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.semantics { heading() }
                )
            }
            IconButton(
                onClick = onEditProfile,
                modifier = Modifier.size(Space.touch),
                colors = IconButtonDefaults.iconButtonColors(containerColor = Mint)
            ) {
                Icon(painterResource(R.drawable.ic_profile), contentDescription = "Ubah profil", tint = Ink)
            }
        }

        // Peringatan prematur tetap terlihat di Beranda.
        if (profile.gestationWeeks != null) {
            InfoNote(PrematureWarning, container = Butter)
        }

        // 2. Hero tahap makan
        PkCard(color = Mint) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(Space.m),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.s)) {
                    Text(
                        "Tahap makan",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        stage.title,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.semantics { heading() }
                    )
                }
                Image(
                    painter = painterResource(R.drawable.ill_hero_baby),
                    contentDescription = null, // dekoratif
                    modifier = Modifier.size(88.dp)
                )
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(Space.s),
                verticalArrangement = Arrangement.spacedBy(Space.s)
            ) {
                MetaPill("Usia ${age.chronoText}")
                MetaPill("Tekstur: ${stage.texture}")
            }
            if (age.correctedText != null) {
                Text(
                    "Usia koreksi: ${age.correctedText}. Hanya perkiraan untuk menyaring panduan umum, bukan penentu tahap makan.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(stage.note, style = MaterialTheme.typography.bodyMedium)
            Button(
                onClick = { showGuide = true },
                modifier = Modifier.heightIn(min = Space.touch)
            ) { Text("Lihat panduan") }
        }

        // 3. Menu hari ini
        PkCard(color = Butter) {
            SectionHeader("Menu hari ini")
            if (todayPlan.isNotEmpty()) {
                todayPlan.forEach { e ->
                    val r = if (e.recipeId.isNotEmpty()) Recipes.firstOrNull { it.id == e.recipeId } else null
                    val art = if (r != null) recipeArt(r) else null
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(Space.m),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IllustrationTile(
                            res = art?.res ?: R.drawable.ill_bowl,
                            contentDescription = art?.description,
                            background = art?.tint ?: Mint,
                            size = 56.dp
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                e.meal,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(e.title, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
                TextButton(onClick = onOpenPlanner) { Text("Buka planner") }
            } else if (menu != null) {
                val art = recipeArt(menu)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(Space.m),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IllustrationTile(
                        res = art.res,
                        contentDescription = art.description,
                        background = art.tint,
                        size = 72.dp
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                        Text(
                            "Saran",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(menu.title, style = MaterialTheme.typography.titleMedium)
                    }
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(Space.s),
                    verticalArrangement = Arrangement.spacedBy(Space.s)
                ) {
                    MetaPill("Tekstur: ${menu.texture}")
                    MetaPill("±${menu.minutes} menit")
                }
                Text(allergenSummary(menu), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = onOpenRecipes) { Text("Lihat semua resep") }
            } else if (age.stageMonths >= 6) {
                EmptyState(
                    art = R.drawable.ill_empty_bowl,
                    title = "Belum ada saran menu",
                    body = "Belum ada resep yang cocok dengan filter alergen Anda."
                )
            } else {
                EmptyState(
                    art = R.drawable.ill_empty_bowl,
                    title = "Belum waktunya MPASI",
                    body = "Resep MPASI tersedia mulai usia 6 bulan. Sampai saat itu, ASI atau sufor tetap nutrisi utama."
                )
            }
        }

        // 4. Ringkasan jurnal (hitungan saja, tanpa skor atau penilaian)
        PkCard(color = Sky) {
            SectionHeader("Ringkasan jurnal")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.l)) {
                StatBlock(todayCount, "Catatan hari ini", Modifier.weight(1f))
                StatBlock(foodCount, "Menu atau bahan berbeda yang sudah dicoba", Modifier.weight(1f))
            }
            if (recentAllergy) {
                InfoNote(
                    "Ada dugaan reaksi yang Anda catat dalam 7 hari terakhir. Bicarakan dengan dokter anak sebelum menawarkan bahan itu lagi.",
                    container = Peach
                )
            }
        }

        // 5. Pintasan
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.m)) {
            ShortcutTile(R.drawable.ic_planner, "Planner", onOpenPlanner, Modifier.weight(1f))
            ShortcutTile(R.drawable.ic_journal, "Jurnal", onOpenJournal, Modifier.weight(1f))
            ShortcutTile(R.drawable.ic_education, "Edukasi", onOpenEducation, Modifier.weight(1f))
        }

        // 6. Pengingat keamanan (isi tidak berkurang)
        PkCard(color = Peach) {
            Row(horizontalArrangement = Arrangement.spacedBy(Space.s), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painterResource(R.drawable.ic_info),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    "Pengingat keamanan",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.semantics { heading() }
                )
            }
            Text("• Jangan beri madu sebelum usia 12 bulan.", style = MaterialTheme.typography.bodyMedium)
            Text("• Tanpa tambahan garam dan gula.", style = MaterialTheme.typography.bodyMedium)
            Text(
                "• Hindari makanan keras atau bulat utuh yang bisa membuat tersedak.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "• Kenalkan bahan baru satu per satu dan perhatikan reaksi anak.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "Aplikasi ini bukan pengganti dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    if (showGuide) {
        ModalBottomSheet(
            onDismissRequest = { showGuide = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Paper
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = Space.screen)
                    .padding(bottom = Space.xxl),
                verticalArrangement = Arrangement.spacedBy(Space.m)
            ) {
                Text(
                    "Panduan tahap makan",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.semantics { heading() }
                )
                Text(stage.title, style = MaterialTheme.typography.titleLarge)
                Text("Tekstur: ${stage.texture}", style = MaterialTheme.typography.bodyLarge)
                Text("Jadwal: ${stage.frequency}", style = MaterialTheme.typography.bodyLarge)
                Text(stage.note, style = MaterialTheme.typography.bodyMedium)
                if (stage.source.isNotBlank()) {
                    Text(
                        stage.source,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                UnverifiedNote()
                if (age.correctedText != null) {
                    Text(
                        "Usia koreksi: ${age.correctedText}. Hanya perkiraan untuk menyaring panduan umum, bukan penentu tahap makan.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (profile.gestationWeeks != null) {
                    InfoNote(PrematureWarning, container = Butter)
                }
                TextButton(onClick = { showGuide = false }) { Text("Tutup") }
            }
        }
    }
}

@Composable
private fun StatBlock(value: Int, label: String, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(Space.xs)) {
        Text(value.toString(), style = MaterialTheme.typography.headlineSmall)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ShortcutTile(@androidx.annotation.DrawableRes icon: Int, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .heightIn(min = Space.touch)
            .clip(MaterialTheme.shapes.large)
            .background(Color.White)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = Space.m, horizontal = Space.xs),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(Space.xs)
    ) {
        Icon(painterResource(icon), contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
    }
}
