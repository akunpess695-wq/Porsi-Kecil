package com.porsikecil.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1300)
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🥣", fontSize = 72.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                "PorsiKecil",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Little Meals, Big Growth.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private data class OnboardingPage(
    val emoji: String,
    val title: String,
    val text: String,
    val color: Color
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = listOf(
        OnboardingPage(
            "🥕", "Resep MPASI yang mudah",
            "Bahan dari pasar dan warung terdekat, lengkap dengan takaran dalam gram.",
            Mint
        ),
        OnboardingPage(
            "✨", "Menu dari bahan di rumah",
            "Tulis bahan yang ada, AI bantu menyusun menu sesuai usia si kecil.",
            Lavender
        ),
        OnboardingPage(
            "📅", "Jadwal dan jurnal makan",
            "Rencanakan menu seminggu, buat daftar belanja, dan catat makanan yang sudah dicoba.",
            Butter
        )
    )
    val state = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val last = state.currentPage == pages.lastIndex

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(24.dp)
    ) {
        HorizontalPager(state = state, modifier = Modifier.weight(1f)) { i ->
            val pg = pages[i]
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier
                        .size(180.dp)
                        .clip(CircleShape)
                        .background(pg.color),
                    contentAlignment = Alignment.Center
                ) {
                    Text(pg.emoji, fontSize = 84.sp)
                }
                Spacer(Modifier.height(28.dp))
                Text(
                    pg.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    pg.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            repeat(pages.size) { i ->
                val active = i == state.currentPage
                Box(
                    Modifier
                        .padding(4.dp)
                        .size(if (active) 22.dp else 8.dp, 8.dp)
                        .clip(CircleShape)
                        .background(
                            if (active) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        )
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (last) onFinish()
                else scope.launch { state.animateScrollToPage(state.currentPage + 1) }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(if (last) "Mulai" else "Lanjut")
        }
    }
}
