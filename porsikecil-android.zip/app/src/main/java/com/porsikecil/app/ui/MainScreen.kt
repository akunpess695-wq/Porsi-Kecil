package com.porsikecil.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.data.stageFor
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky

@Composable
fun SoftCard(
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun MainScreen(profile: BabyProfile, onEditProfile: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "🏠" to "Beranda",
        "📖" to "Resep",
        "✨" to "AI",
        "📅" to "Planner",
        "📝" to "Jurnal"
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(item.first, fontSize = 22.sp) },
                        label = { Text(item.second) }
                    )
                }
            }
        }
    ) { pad: PaddingValues ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(profile, onEditProfile)
                1 -> ComingSoon("Resep", "📖", "Sprint 2", "Database bahan dan resep MPASI dengan takaran gram.")
                2 -> ComingSoon("AI Assistant", "✨", "Sprint 4", "Menu dari bahan di rumah dan tanya jawab nutrisi.")
                3 -> ComingSoon("Planner", "📅", "Sprint 5", "Kalender menu mingguan dan daftar belanja otomatis.")
                else -> ComingSoon("Jurnal Makanan", "📝", "Sprint 5", "Riwayat makanan, porsi, dan respons bayi.")
            }
        }
    }
}

@Composable
fun HomeScreen(profile: BabyProfile, onEditProfile: () -> Unit) {
    val age = remember(profile) { calculateAge(profile) }
    val stage = stageFor(age.stageMonths)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Halo! 👋", style = MaterialTheme.typography.bodyLarge)
                Text(
                    profile.name,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            TextButton(onClick = onEditProfile) { Text("Ubah profil") }
        }

        SoftCard(Peach) {
            Text("👶 Usia", style = MaterialTheme.typography.labelLarge)
            Text(age.chronoText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (age.correctedText != null) {
                Text("Usia koreksi: ${age.correctedText}. Dipakai sebagai acuan tahap makan.")
            }
        }

        SoftCard(Mint) {
            Text("🥣 Tahap makan", style = MaterialTheme.typography.labelLarge)
            Text(stage.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Tekstur: ${stage.texture}")
            Text("Jadwal: ${stage.frequency}")
            Text(stage.note, style = MaterialTheme.typography.bodySmall)
        }

        SoftCard(Butter) {
            Text("🍽️ Menu hari ini", style = MaterialTheme.typography.labelLarge)
            Text("Segera hadir setelah database resep siap (Sprint 2).")
        }

        SoftCard(Lavender) {
            Text("✨ Tanya AI", style = MaterialTheme.typography.labelLarge)
            Text("Menu dari bahan di rumah dan saran nutrisi (Sprint 4).")
        }

        SoftCard(Sky) {
            Text("📊 Ringkasan nutrisi", style = MaterialTheme.typography.labelLarge)
            Text("Kalori, protein, dan zat besi dari menu yang dicatat (Sprint 3).")
        }

        SoftCard(Peach) {
            Text("🛡️ Pengingat keamanan", style = MaterialTheme.typography.labelLarge)
            Text("• Jangan beri madu sebelum usia 12 bulan.")
            Text("• Tanpa tambahan garam dan gula.")
            Text("• Hindari makanan keras atau bulat utuh yang bisa membuat tersedak.")
            Text("• Kenalkan bahan baru satu per satu, tunggu 2–3 hari.")
            Text(
                "Aplikasi ini bukan pengganti dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun ComingSoon(title: String, emoji: String, sprint: String, text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 64.sp)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Segera hadir ($sprint)",
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
