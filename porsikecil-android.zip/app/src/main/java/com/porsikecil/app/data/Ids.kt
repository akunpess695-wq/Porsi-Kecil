package com.porsikecil.app.data

import java.util.concurrent.atomic.AtomicLong

private val lastId = AtomicLong(0L)

/** ID unik dan naik terus, aman walau dibuat dalam milidetik yang sama. */
fun newId(): Long {
    val now = System.currentTimeMillis()
    return lastId.updateAndGet { prev -> if (now > prev) now else prev + 1 }
}
