package com.porsikecil.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Space

/*
 * Komponen reusable PorsiKecil 2.0. Layar baru/diperbarui memakai komponen ini
 * alih-alih menyusun Card/Text sendiri. Lihat PORSIKECIL_HANDOFF.md untuk status migrasi.
 */

/** Kartu standar: radius `large`, padding 16 dp, jarak antarisi 8 dp. Bisa diketuk bila [onClick] diberikan. */
@Composable
fun PkCard(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    val inner: @Composable () -> Unit = {
        Column(
            Modifier.padding(Space.l),
            verticalArrangement = Arrangement.spacedBy(Space.s),
            content = content
        )
    }
    if (onClick == null) {
        Card(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, colors = colors) { inner() }
    } else {
        Card(
            modifier = modifier.fillMaxWidth().clip(MaterialTheme.shapes.large).clickable(onClick = onClick),
            shape = MaterialTheme.shapes.large,
            colors = colors
        ) { inner() }
    }
}

/** Ilustrasi lokal di atas latar berwarna, dipakai sebagai "thumbnail" resep/bahan. */
@Composable
fun IllustrationTile(
    @DrawableRes res: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    background: Color = Mint,
    size: Dp = 72.dp
) {
    Box(
        modifier
            .size(size)
            .clip(MaterialTheme.shapes.medium)
            .background(background),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(res),
            contentDescription = contentDescription,
            modifier = Modifier.fillMaxSize(0.8f)
        )
    }
}

/**
 * Gambar resep. PNG resep adalah adegan penuh 4:3 (bahan pendamping ada di tepi kiri/kanan), jadi
 * ditampilkan memenuhi bingkai ber-rasio tetap, tanpa latar tile dan tanpa dikecilkan ke 80%.
 * Lebar ditentukan pemanggil lewat [modifier] (mis. `Modifier.width(96.dp)` atau `fillMaxWidth()`).
 * Pakai [aspectRatio] 4/3 agar tidak ada yang terpotong; rasio lebih lebar (mis. 3/2) hanya memangkas
 * ruang kosong di atas/bawah. Placeholder mangkuk (id belum dikenal) tetap tampil di atas tint.
 */
@Composable
fun RecipeImage(
    art: RecipeArtSpec,
    modifier: Modifier = Modifier,
    aspectRatio: Float = 4f / 3f,
    shape: Shape = MaterialTheme.shapes.medium
) {
    if (art.isFullScene()) {
        Image(
            painter = painterResource(art.res),
            contentDescription = art.description,
            contentScale = ContentScale.Crop,
            alignment = Alignment.Center,
            modifier = modifier.aspectRatio(aspectRatio).clip(shape)
        )
    } else {
        Box(
            modifier.aspectRatio(aspectRatio).clip(shape).background(art.tint),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(art.res),
                contentDescription = art.description,
                modifier = Modifier.fillMaxHeight(0.8f)
            )
        }
    }
}

/** Metadata kecil (usia, tekstur, waktu masak). Teks selalu ada, tidak mengandalkan warna. */
@Composable
fun MetaPill(text: String, modifier: Modifier = Modifier, container: Color = Color.White.copy(alpha = 0.75f)) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(container)
            .padding(horizontal = Space.m, vertical = Space.xs)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = Ink)
    }
}

/** Judul bagian + aksi opsional (mis. "Lihat semua"). Judul ditandai sebagai heading untuk TalkBack. */
@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .weight(1f)
                .semantics { heading() }
        )
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Catatan/penafian ringkas dengan ikon info (untuk batasan filter alergen, status verifikasi, dll.). */
@Composable
fun InfoNote(text: String, modifier: Modifier = Modifier, container: Color = Butter) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(container)
            .padding(Space.m),
        horizontalArrangement = Arrangement.spacedBy(Space.s),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            painterResource(com.porsikecil.app.R.drawable.ic_info),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Text(text, style = MaterialTheme.typography.bodySmall, color = Ink)
    }
}

/** Keadaan kosong dengan ilustrasi, judul, dan penjelasan. */
@Composable
fun EmptyState(
    @DrawableRes art: Int,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(vertical = Space.xl, horizontal = Space.l),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(Space.s)
    ) {
        Image(
            painter = painterResource(art),
            contentDescription = null, // dekoratif; judul di bawah membawa maknanya
            modifier = Modifier.size(120.dp)
        )
        Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionLabel != null && onAction != null) {
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

/** Tombol kembali dengan ikon custom + teks, target sentuh >= 48 dp. */
@Composable
fun BackButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    TextButton(onClick = onClick, modifier = modifier.heightIn(min = Space.touch)) {
        Icon(painterResource(com.porsikecil.app.R.drawable.ic_back), contentDescription = null, modifier = Modifier.size(20.dp))
        Text("Kembali", modifier = Modifier.padding(start = Space.xs))
    }
}
