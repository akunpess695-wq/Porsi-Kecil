package com.porsikecil.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.porsikecil.app.data.DayNames
import com.porsikecil.app.data.MealTypes
import com.porsikecil.app.data.PlanEntry
import com.porsikecil.app.data.Recipes
import com.porsikecil.app.data.allergens
import com.porsikecil.app.data.ShoppingItem
import com.porsikecil.app.data.buildShoppingFromPlan
import com.porsikecil.app.data.mergeShopping
import com.porsikecil.app.data.newId
import com.porsikecil.app.data.weekStart
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun PlannerScreen(
    stageMonths: Int,
    avoid: Set<String>,
    plan: List<PlanEntry>,
    onPlanChange: (List<PlanEntry>) -> Unit,
    shopping: List<ShoppingItem>,
    onShoppingChange: (List<ShoppingItem>) -> Unit
) {
    var section by remember { mutableStateOf("Jadwal") }
    var weekOffset by remember { mutableIntStateOf(0) }
    val start = weekStart(LocalDate.now()).plusWeeks(weekOffset.toLong())

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Planner",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        ChipRow(listOf("Jadwal", "Belanja"), section) { section = it }
        WeekHeader(start, onPrev = { weekOffset -= 1 }, onNext = { weekOffset += 1 })
        if (section == "Jadwal") {
            WeekPlan(
                stageMonths = stageMonths,
                avoid = avoid,
                start = start,
                plan = plan,
                onPlanChange = onPlanChange,
                modifier = Modifier.weight(1f)
            )
        } else {
            ShoppingSection(
                start = start,
                plan = plan,
                shopping = shopping,
                onChange = onShoppingChange,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

private fun dateFormatter(): DateTimeFormatter =
    DateTimeFormatter.ofPattern("d MMM", Locale.forLanguageTag("id-ID"))

@Composable
private fun WeekHeader(start: LocalDate, onPrev: () -> Unit, onNext: () -> Unit) {
    val f = remember { dateFormatter() }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onPrev) { Text("‹ Sebelumnya") }
        Text(
            "${start.format(f)} – ${start.plusDays(6).format(f)}",
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.labelLarge
        )
        TextButton(onClick = onNext) { Text("Berikutnya ›") }
    }
}

@Composable
private fun WeekPlan(
    stageMonths: Int,
    avoid: Set<String>,
    start: LocalDate,
    plan: List<PlanEntry>,
    onPlanChange: (List<PlanEntry>) -> Unit,
    modifier: Modifier
) {
    var addForDay by remember { mutableStateOf<LocalDate?>(null) }
    val f = remember { dateFormatter() }
    val todayDate = LocalDate.now()
    val dayColors = listOf(Peach, Mint, Lavender, Butter, Sky, Peach, Mint)

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        for (i in 0..6) {
            val date = start.plusDays(i.toLong())
            val items = plan
                .filter { it.epochDay == date.toEpochDay() }
                .sortedBy { MealTypes.indexOf(it.meal) }
            val isToday = date == todayDate
            SoftCard(dayColors[i]) {
                Text(
                    "${DayNames[i]}, ${date.format(f)}" + if (isToday) " (hari ini)" else "",
                    style = MaterialTheme.typography.labelLarge
                )
                if (items.isEmpty()) {
                    Text(
                        "Belum ada menu.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                items.forEach { e ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "• ${e.meal}: ${e.title}",
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            onPlanChange(plan.filter { it.id != e.id })
                        }) { Text("Hapus") }
                    }
                }
                TextButton(onClick = { addForDay = date }) { Text("+ Tambah menu") }
            }
        }
    }

    val day = addForDay
    if (day != null) {
        AddPlanDialog(
            date = day,
            stageMonths = stageMonths,
            avoid = avoid,
            onDismiss = { addForDay = null },
            onSave = { entry ->
                onPlanChange(plan + entry)
                addForDay = null
            }
        )
    }
}

@Composable
private fun AddPlanDialog(
    date: LocalDate,
    stageMonths: Int,
    avoid: Set<String>,
    onDismiss: () -> Unit,
    onSave: (PlanEntry) -> Unit
) {
    var meal by remember { mutableStateOf(MealTypes[0]) }
    var mode by remember { mutableStateOf("Pilih resep") }
    var selectedId by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }
    val pool = remember(stageMonths) { Recipes.filter { it.minMonths <= stageMonths }.ifEmpty { Recipes } }
    val f = remember { dateFormatter() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah menu, ${DayNames[date.dayOfWeek.value - 1]} ${date.format(f)}") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Waktu makan", style = MaterialTheme.typography.labelLarge)
                ChipRow(MealTypes, meal) { meal = it }
                ChipRow(listOf("Pilih resep", "Tulis sendiri"), mode) { mode = it }
                if (mode == "Pilih resep") {
                    if (stageMonths < 6) {
                        Text(
                            "Si kecil belum 6 bulan. Jadwal ini hanya untuk persiapan, mulai MPASI sesuai arahan dokter anak.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    pool.forEach { r ->
                        val on = r.id == selectedId
                        val hit = r.allergens.filter { it in avoid }
                        Text(
                            r.title + if (hit.isNotEmpty()) "\nMengandung ${hit.joinToString(", ")} (Anda hindari)" else "",
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (on) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable { selectedId = r.id }
                                .padding(10.dp),
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = custom,
                        onValueChange = { custom = it.take(60) },
                        label = { Text("Nama menu") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            val canSave = if (mode == "Pilih resep") selectedId.isNotEmpty() else custom.isNotBlank()
            TextButton(
                enabled = canSave,
                onClick = {
                    val recipe = Recipes.firstOrNull { it.id == selectedId }
                    val useRecipe = mode == "Pilih resep" && recipe != null
                    onSave(
                        PlanEntry(
                            id = newId(),
                            epochDay = date.toEpochDay(),
                            meal = meal,
                            recipeId = if (useRecipe) selectedId else "",
                            title = if (useRecipe && recipe != null) recipe.title else custom.trim()
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
private fun ShoppingSection(
    start: LocalDate,
    plan: List<PlanEntry>,
    shopping: List<ShoppingItem>,
    onChange: (List<ShoppingItem>) -> Unit,
    modifier: Modifier
) {
    var showAdd by remember { mutableStateOf(false) }
    val startDay = start.toEpochDay()
    val weekEntries = plan.filter { it.epochDay >= startDay && it.epochDay <= startDay + 6 }
    val sorted = shopping.sortedBy { it.checked }
    val remaining = shopping.count { !it.checked }

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Daftar dibuat dari bahan resep di jadwal minggu yang dipilih. Centang bahan yang sudah ada di rumah atau sudah dibeli.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(
            onClick = {
                onChange(mergeShopping(shopping, buildShoppingFromPlan(weekEntries)))
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) { Text("Buat dari jadwal minggu ini") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { showAdd = true }) { Text("+ Tambah item") }
            TextButton(
                enabled = shopping.any { it.checked },
                onClick = { onChange(shopping.filter { !it.checked }) }
            ) { Text("Hapus yang dicentang") }
        }

        if (shopping.isEmpty()) {
            SoftCard(Butter) {
                Text("Daftar masih kosong", fontWeight = FontWeight.Bold)
                Text("Tambahkan resep ke jadwal, lalu tekan tombol di atas. Anda juga bisa menambah item sendiri.")
            }
        } else {
            Text("Belum dibeli: $remaining dari ${shopping.size}", style = MaterialTheme.typography.labelLarge)
            sorted.forEach { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = item.checked,
                        onCheckedChange = { c ->
                            onChange(shopping.map { if (it.id == item.id) it.copy(checked = c) else it })
                        }
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            item.name,
                            fontWeight = FontWeight.SemiBold,
                            textDecoration = if (item.checked) TextDecoration.LineThrough else TextDecoration.None
                        )
                        if (item.amount.isNotBlank()) {
                            Text(
                                item.amount,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    TextButton(onClick = {
                        onChange(shopping.filter { it.id != item.id })
                    }) { Text("Hapus") }
                }
            }
        }
    }

    if (showAdd) {
        AddShoppingDialog(
            onDismiss = { showAdd = false },
            onSave = { item ->
                onChange(shopping + item)
                showAdd = false
            }
        )
    }
}

@Composable
private fun AddShoppingDialog(onDismiss: () -> Unit, onSave: (ShoppingItem) -> Unit) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah item belanja") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Nama bahan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.take(30) },
                    label = { Text("Jumlah (opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        ShoppingItem(
                            id = newId(),
                            name = name.trim(),
                            amount = amount.trim(),
                            checked = false,
                            auto = false
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
