package com.porsikecil.app.data

import java.time.LocalDate
import java.time.Period

data class AgeInfo(
    val chronoText: String,
    val correctedText: String?,
    /** Usia (bulan) yang dipakai untuk menentukan tahap makan. */
    val stageMonths: Int
)

fun periodText(p: Period): String {
    val m = p.years * 12 + p.months
    val d = p.days
    return when {
        m == 0 -> "$d hari"
        d == 0 -> "$m bulan"
        else -> "$m bulan $d hari"
    }
}

/** Usia dihitung dari tanggal lahir. Untuk bayi prematur dihitung juga usia koreksi. */
fun calculateAge(p: BabyProfile, today: LocalDate = LocalDate.now()): AgeInfo {
    val chrono = Period.between(p.birthDate, today)
    val chronoMonths = chrono.years * 12 + chrono.months
    val earlyWeeks = p.gestationWeeks?.let { (40 - it).coerceAtLeast(0) } ?: 0
    if (earlyWeeks == 0) return AgeInfo(periodText(chrono), null, chronoMonths)

    val correctedBirth = p.birthDate.plusWeeks(earlyWeeks.toLong())
    val corrected = if (correctedBirth.isAfter(today)) Period.ZERO else Period.between(correctedBirth, today)
    val correctedMonths = corrected.years * 12 + corrected.months
    return AgeInfo(periodText(chrono), periodText(corrected), correctedMonths)
}

data class FeedingStage(
    val title: String,
    val texture: String,
    val frequency: String,
    val note: String
)

fun stageFor(months: Int): FeedingStage = when {
    months < 6 -> FeedingStage(
        "Belum masuk tahap MPASI",
        "ASI atau sufor",
        "Sesuai kebutuhan bayi",
        "MPASI umumnya dimulai sekitar 6 bulan. Tanda siap: kepala tegak, bisa duduk dengan sedikit bantuan, dan tertarik pada makanan. Pastikan dengan dokter anak."
    )
    months < 7 -> FeedingStage(
        "Tahap 1 (6 bulan)",
        "Halus: bubur saring atau puree kental",
        "2–3 kali makan, 2–3 sdm per makan. ASI tetap utama.",
        "Kenalkan satu bahan baru setiap 2–3 hari. Utamakan makanan kaya zat besi."
    )
    months < 9 -> FeedingStage(
        "Tahap 2 (7–8 bulan)",
        "Lumat: bubur atau tim kasar",
        "2–3 kali makan + 1 selingan, ±125 ml per makan.",
        "Tambahkan protein hewani setiap hari dan lemak tambahan 1 sdt per porsi."
    )
    months < 12 -> FeedingStage(
        "Tahap 3 (9–11 bulan)",
        "Cincang kasar dan finger food lunak",
        "3 kali makan + 1–2 selingan, ±125–175 ml per makan.",
        "Latih bayi memegang makanan sendiri. Awasi selama makan."
    )
    else -> FeedingStage(
        "Tahap 4 (12 bulan ke atas)",
        "Makanan keluarga, dipotong kecil",
        "3 kali makan + 1–2 selingan.",
        "Tetap batasi garam dan gula, hindari pedas serta makanan keras atau bulat utuh."
    )
}
