package com.porsikecil.app.ui

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Image
import com.porsikecil.app.R
import androidx.compose.ui.res.painterResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.JournalEntry
import com.porsikecil.app.data.JournalRepository
import com.porsikecil.app.data.PlannerRepository
import com.porsikecil.app.data.UserPrefsRepository
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach

@Composable
fun SoftCard(
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun MainScreen(
    profile: BabyProfile,
    journalRepo: JournalRepository,
    plannerRepo: PlannerRepository,
    onEditProfile: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showJournal by rememberSaveable { mutableStateOf(false) }
    var entries by remember { mutableStateOf(journalRepo.load()) }
    var draftFood by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val prefsRepo = remember { UserPrefsRepository(context) }
    var avoid by remember { mutableStateOf(prefsRepo.loadAvoid()) }
    var favorites by remember { mutableStateOf(prefsRepo.loadFavorites()) }
    var plan by remember { mutableStateOf(plannerRepo.loadPlan()) }
    var shopping by remember { mutableStateOf(plannerRepo.loadShopping()) }
    val age = remember(profile) { calculateAge(profile) }
    val tabs = listOf(
        R.drawable.ic_home to "Beranda",
        R.drawable.ic_recipes to "Resep",
        R.drawable.ic_planner to "Planner",
        R.drawable.ic_education to "Edukasi",
        R.drawable.ic_profile to "Profil"
    )
    BackHandler(enabled = showJournal) { showJournal = false }
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            tab = i
                            showJournal = false
                        },
                        icon = { Icon(painterResource(item.first), contentDescription = null) },
                        label = { Text(item.second) }
                    )
                }
            }
        }
    ) { pad: PaddingValues ->
        Box(Modifier.padding(pad)) {
            if (showJournal) {
                Column(Modifier.fillMaxSize()) {
                    BackButton(onClick = { showJournal = false }, modifier = Modifier.padding(start = 8.dp, top = 4.dp))
                    Box(Modifier.weight(1f)) {
                        JournalScreen(
                            entries = entries,
                            pendingFood = draftFood,
                            onPendingHandled = { draftFood = null },
                            onAdd = { e ->
                                val updated = (entries + e).sortedWith(
                                    compareByDescending<JournalEntry> { it.epochDay }.thenByDescending { it.id }
                                )
                                entries = updated
                                journalRepo.save(updated)
                            },
                            onDelete = { e ->
                                val updated = entries.filter { it.id != e.id }
                                entries = updated
                                journalRepo.save(updated)
                            }
                        )
                    }
                }
            } else {
                when (tab) {
                    0 -> HomeScreen(
                        profile = profile,
                        avoid = avoid,
                        entries = entries,
                        plan = plan,
                        onEditProfile = onEditProfile,
                        onOpenRecipes = { tab = 1 },
                        onOpenPlanner = { tab = 2 },
                        onOpenJournal = { showJournal = true },
                        onOpenEducation = { tab = 3 }
                    )
                    1 -> RecipeScreen(
                        stageMonths = age.stageMonths,
                        avoid = avoid,
                        onAvoidChange = { v ->
                            avoid = v
                            prefsRepo.saveAvoid(v)
                        },
                        favorites = favorites,
                        onFavoritesChange = { v ->
                            favorites = v
                            prefsRepo.saveFavorites(v)
                        },
                        onLog = { title ->
                            draftFood = title
                            showJournal = true
                        }
                    )
                    2 -> PlannerScreen(
                        stageMonths = age.stageMonths,
                        avoid = avoid,
                        plan = plan,
                        onPlanChange = { updated ->
                            plan = updated
                            plannerRepo.savePlan(updated)
                        },
                        shopping = shopping,
                        onShoppingChange = { updated ->
                            shopping = updated
                            plannerRepo.saveShopping(updated)
                        }
                    )
                    3 -> ComingSoon(
                        "Edukasi", R.drawable.ill_empty_bowl, "tahap berikutnya",
                        "Materi keamanan dan gizi MPASI dengan sumber yang bisa diperiksa."
                    )
                    else -> ProfileTab(
                        profile = profile,
                        avoid = avoid,
                        favoriteCount = favorites.size,
                        onEditProfile = onEditProfile,
                        onOpenJournal = { showJournal = true },
                        onOpenRecipes = { tab = 1 }
                    )
                }
            }
        }
    }
}

@Composable
fun ComingSoon(title: String, @androidx.annotation.DrawableRes art: Int, sprint: String, text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(art), contentDescription = null, modifier = Modifier.size(120.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Segera hadir ($sprint)",
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
