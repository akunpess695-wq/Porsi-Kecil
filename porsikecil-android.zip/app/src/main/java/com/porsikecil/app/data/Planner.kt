package com.porsikecil.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** recipeId kosong berarti menu tulis sendiri. */
data class PlanEntry(
    val id: Long,
    val epochDay: Long,
    val meal: String,
    val recipeId: String,
    val title: String
)

data class ShoppingItem(
    val id: Long,
    val name: String,
    val amount: String,
    val checked: Boolean,
    /** true jika dibuat otomatis dari jadwal. */
    val auto: Boolean
)

val DayNames = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")

/** Hari Senin dari minggu tempat tanggal tersebut berada. */
fun weekStart(date: LocalDate): LocalDate = date.minusDays((date.dayOfWeek.value - 1).toLong())

private val amountRegex = Regex("""^\s*(\d+(?:[.,]\d+)?)\s*(g|ml)\b""")

private class Acc(val display: String) {
    val sums = LinkedHashMap<String, Double>()
    val others = ArrayList<String>()
}

private fun formatNumber(v: Double): String {
    val rounded = Math.round(v * 10) / 10.0
    return if (rounded == rounded.toLong().toDouble()) rounded.toLong().toString()
    else rounded.toString().replace('.', ',')
}

/**
 * Menggabungkan bahan dari resep yang ada di jadwal.
 * Takaran gram dan ml dijumlahkan; takaran lain (butir, sdm, dst) digabung sebagai teks.
 * Air dan ASI tidak dimasukkan. Menu tulis sendiri tidak punya daftar bahan.
 */
fun buildShoppingFromPlan(entries: List<PlanEntry>): List<Pair<String, String>> {
    val map = LinkedHashMap<String, Acc>()
    for (entry in entries) {
        val recipe = Recipes.firstOrNull { it.id == entry.recipeId } ?: continue
        for (ing in recipe.ingredients) {
            if (ing.name.startsWith("Air", ignoreCase = true) || ing.name.contains("ASI")) continue
            val key = ing.name.trim().lowercase()
            val acc = map.getOrPut(key) { Acc(ing.name.trim()) }
            val m = amountRegex.find(ing.amount)
            if (m != null) {
                val value = m.groupValues[1].replace(',', '.').toDouble()
                val unit = m.groupValues[2]
                acc.sums[unit] = (acc.sums[unit] ?: 0.0) + value
            } else {
                acc.others.add(ing.amount)
            }
        }
    }
    return map.values.map { acc ->
        val parts = ArrayList<String>()
        for ((unit, v) in acc.sums) parts.add(formatNumber(v) + " " + unit)
        parts.addAll(acc.others)
        Pair(acc.display, parts.joinToString(" + "))
    }
}

/** Item manual dipertahankan; item otomatis diganti, status centang dipertahankan jika bahannya sama. */
fun mergeShopping(existing: List<ShoppingItem>, generated: List<Pair<String, String>>): List<ShoppingItem> {
    val keep = existing.filter { !it.auto }
    val checkedBefore = existing.filter { it.auto && it.checked }.map { it.name.lowercase() }.toSet()
    val autos = generated.map { p ->
        ShoppingItem(
            id = newId(),
            name = p.first,
            amount = p.second,
            checked = p.first.lowercase() in checkedBefore,
            auto = true
        )
    }
    return keep + autos
}

class PlannerRepository(context: Context) {
    private val prefs = context.getSharedPreferences("porsikecil_planner", Context.MODE_PRIVATE)

    /** Simpan salinan data yang gagal dibaca agar tidak hilang saat disimpan ulang. */
    private fun preserveCorrupt(key: String, raw: String) {
        prefs.edit().putString(key + "_corrupt_backup", raw).apply()
    }

    fun loadPlan(): List<PlanEntry> {
        val raw = prefs.getString("plan", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val result = ArrayList<PlanEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    PlanEntry(
                        id = o.getLong("id"),
                        epochDay = o.getLong("day"),
                        meal = o.optString("meal"),
                        recipeId = o.optString("recipe"),
                        title = o.optString("title")
                    )
                )
            }
            result
        } catch (e: Exception) {
            preserveCorrupt("plan", raw)
            emptyList()
        }
    }

    fun savePlan(list: List<PlanEntry>) {
        val arr = JSONArray()
        for (e in list) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("day", e.epochDay)
            o.put("meal", e.meal)
            o.put("recipe", e.recipeId)
            o.put("title", e.title)
            arr.put(o)
        }
        prefs.edit().putString("plan", arr.toString()).apply()
    }

    fun loadShopping(): List<ShoppingItem> {
        val raw = prefs.getString("shopping", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val result = ArrayList<ShoppingItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    ShoppingItem(
                        id = o.getLong("id"),
                        name = o.optString("name"),
                        amount = o.optString("amount"),
                        checked = o.optBoolean("checked", false),
                        auto = o.optBoolean("auto", false)
                    )
                )
            }
            result
        } catch (e: Exception) {
            preserveCorrupt("shopping", raw)
            emptyList()
        }
    }

    fun saveShopping(list: List<ShoppingItem>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("id", s.id)
            o.put("name", s.name)
            o.put("amount", s.amount)
            o.put("checked", s.checked)
            o.put("auto", s.auto)
            arr.put(o)
        }
        prefs.edit().putString("shopping", arr.toString()).apply()
    }
}
