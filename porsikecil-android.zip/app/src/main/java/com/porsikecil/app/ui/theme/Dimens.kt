package com.porsikecil.app.ui.theme

import androidx.compose.ui.unit.dp

/** Spacing dalam kelipatan 4/8 dp. */
object Space {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    /** Padding horizontal standar layar. */
    val screen = 20.dp
    /** Target sentuh minimum. */
    val touch = 48.dp
}
