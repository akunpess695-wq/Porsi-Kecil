package com.porsikecil.app.ui

import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.porsikecil.app.ui.theme.Space

/**
 * Chip pilihan. Area sentuh minimal 48 dp; chip terpilih diberi tanda centang
 * supaya status tidak hanya dibedakan lewat warna.
 */
@Composable
fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Box(
        Modifier
            .heightIn(min = Space.touch)
            .clip(RoundedCornerShape(50))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(
            Modifier
                .heightIn(min = 36.dp)
                .clip(RoundedCornerShape(50))
                .background(bg)
                .padding(horizontal = Space.l, vertical = Space.xs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Space.xs)
        ) {
            if (selected) {
                Icon(painterResource(com.porsikecil.app.R.drawable.ic_check), contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
            }
            Text(label, color = fg, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(Space.s)
    ) {
        options.forEach { opt ->
            SelectChip(opt, opt == selected) { onSelect(opt) }
        }
    }
}

/** Penanda untuk angka/panduan yang belum ditinjau ahli. */
@Composable
fun UnverifiedNote(modifier: Modifier = Modifier) {
    Text(
        "Panduan umum. Angka belum ditinjau ahli (perlu verifikasi). Ikuti saran dokter anak atau bidan.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier
    )
}
