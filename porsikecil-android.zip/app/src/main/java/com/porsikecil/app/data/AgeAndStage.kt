package com.porsikecil.app.data

import java.time.LocalDate
import java.time.Period

data class AgeInfo(
    val chronoText: String,
    val correctedText: String?,
    /** Usia (bulan) yang dipakai untuk menentukan tahap makan. */
    val stageMonths: Int
)

fun periodText(p: Period): String {
    val m = p.years * 12 + p.months
    val d = p.days
    return when {
        m == 0 -> "$d hari"
        d == 0 -> "$m bulan"
        else -> "$m bulan $d hari"
    }
}

/** Usia dihitung dari tanggal lahir. Untuk bayi prematur dihitung juga usia koreksi. */
fun calculateAge(p: BabyProfile, today: LocalDate = LocalDate.now()): AgeInfo {
    val chrono = Period.between(p.birthDate, today)
    val chronoMonths = chrono.years * 12 + chrono.months
    val earlyWeeks = p.gestationWeeks?.let { (40 - it).coerceAtLeast(0) } ?: 0
    if (earlyWeeks == 0) return AgeInfo(periodText(chrono), null, chronoMonths)

    val correctedBirth = p.birthDate.plusWeeks(earlyWeeks.toLong())
    val corrected = if (correctedBirth.isAfter(today)) Period.ZERO else Period.between(correctedBirth, today)
    val correctedMonths = corrected.years * 12 + corrected.months
    return AgeInfo(periodText(chrono), periodText(corrected), correctedMonths)
}

data class FeedingStage(
    val title: String,
    val texture: String,
    val frequency: String,
    val note: String,
    /** Sumber/penanda untuk angka frekuensi; kosong jika tidak ada angka. */
    val source: String
)

const val FrequencySource =
    "Frekuensi: batas minimum indikator WHO untuk pemantauan (bukan target wajib). " +
        "Sumber: WHO GHO, Minimum meal frequency (6–23 bulan), diakses 3 Nov 2026. Perlu tinjauan profesional."

/**
 * Jumlah minimum makan per hari menurut indikator WHO (makanan lunak/padat, termasuk selingan).
 * Anak non-ASI: 4 kali makan atau minum susu. Null jika belum 6 bulan.
 */
fun minimumFeedings(months: Int, breastfed: Boolean): Int? = when {
    months < 6 -> null
    !breastfed -> 4
    months < 9 -> 2
    else -> 3
}

fun frequencyText(months: Int): String {
    val bf = minimumFeedings(months, true) ?: return "ASI atau sufor sesuai kebutuhan bayi"
    val nbf = minimumFeedings(months, false)
    return "Anak yang masih ASI: minimal $bf kali makan makanan lunak/padat per hari (termasuk selingan). " +
        "Anak tanpa ASI: minimal $nbf kali makan atau minum susu, sedikitnya satu berupa makanan lunak/padat. " +
        "Ini batas minimum, bukan target; sesuaikan dengan isyarat lapar dan kenyang anak."
}

fun stageFor(months: Int): FeedingStage = when {
    months < 6 -> FeedingStage(
        "Belum masuk tahap MPASI",
        "ASI atau sufor",
        frequencyText(months),
        "MPASI umumnya dimulai sekitar 6 bulan. Kesiapan anak perlu dipastikan bersama dokter anak.",
        ""
    )
    months < 7 -> FeedingStage(
        "Tahap 1 (6 bulan)",
        "Halus: bubur saring atau puree kental",
        frequencyText(months),
        "Mulai dari porsi kecil dan ikuti isyarat anak. ASI tetap dilanjutkan.",
        FrequencySource
    )
    months < 9 -> FeedingStage(
        "Tahap 2 (7–8 bulan)",
        "Lumat: bubur atau tim kasar",
        frequencyText(months),
        "Tekstur dan jumlah menyesuaikan kemampuan dan isyarat anak.",
        FrequencySource
    )
    months < 12 -> FeedingStage(
        "Tahap 3 (9–11 bulan)",
        "Cincang kasar dan finger food lunak",
        frequencyText(months),
        "Latih bayi memegang makanan sendiri. Awasi selama makan.",
        FrequencySource
    )
    else -> FeedingStage(
        "Tahap 4 (12 bulan ke atas)",
        "Makanan keluarga, dipotong kecil",
        frequencyText(months),
        "Tetap batasi garam dan gula, hindari pedas serta makanan keras atau bulat utuh.",
        FrequencySource
    )
}
