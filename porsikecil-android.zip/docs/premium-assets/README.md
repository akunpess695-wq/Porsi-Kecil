# PorsiKecil — Premium Recipe Visual Assets

Paket aset visual untuk proyek Android PorsiKecil (Kotlin + Jetpack Compose).

## Isi
- `android/app/src/main/res/drawable-nodpi/` — 18 PNG ilustrasi makanan beresolusi 1024×768, siap dipakai sebagai drawable Android.
- `svg/` — sumber SVG vektor untuk seluruh ilustrasi (bisa diedit dan diekspor ulang).
- `docs/RecipeArt_mapping.kt` — contoh pemetaan ID resep ke aset `R.drawable`.
- `preview/recipe-assets-contact-sheet.jpg` — lembar pratinjau seluruh aset.
- `docs/CLAUDE_PROMPT.txt` — instruksi siap tempel ke Claude.

## Catatan desain yang jujur
Gambar di paket ini adalah **ilustrasi makanan vektor bergaya editorial**, bukan foto makanan asli. Setiap resep mempunyai file unik dengan palet dan motif bahan yang disesuaikan dengan nama menu. Gaya visual dibuat konsisten agar aplikasi terasa rapi dan premium. Jika nantinya ingin fotografi makanan realistis, aset dapat diganti satu per satu tanpa mengubah ID resep atau struktur pemetaan.

## Cara memasang manual
1. Buka proyek Android PorsiKecil.
2. Salin semua file PNG dari folder `android/app/src/main/res/drawable-nodpi/` ke folder proyek:
   `app/src/main/res/drawable-nodpi/`
   (buat folder `drawable-nodpi` bila belum ada).
3. Buka `RecipeArt.kt` yang sudah ada.
4. Pertahankan `RecipeArtSpec`, import, dan fungsi `foodArt()` yang sekarang.
5. Ganti hanya fungsi `recipeArt(r: Recipe)` dengan fungsi pada `docs/RecipeArt_mapping.kt`.
6. Build dan cek tampilan di perangkat. Jangan mengubah `Recipes.kt` atau data medis.

## Ketentuan kualitas
- Semua aset lokal, tidak membutuhkan internet saat ditampilkan.
- File PNG memakai nama resource Android lowercase dengan underscore.
- Deskripsi aksesibilitas disediakan pada pemetaan resep.
- Jangan menghapus fallback `ill_bowl` untuk ID resep yang belum dikenal.
