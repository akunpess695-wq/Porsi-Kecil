package com.porsikecil.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Palet "Premium Baby Nutrition Experience" (brief 3 Nov 2026).
// Nama lama dipertahankan agar layar yang belum dimigrasi tetap terkompilasi.
val Sage = Color(0xFF426B55)      // utama
val Mint = Color(0xFFE7EFE6)      // sage muda
val Paper = Color(0xFFFAF8F1)     // cream / latar
val Peach = Color(0xFFFBEADF)
val Honey = Color(0xFFF4D98B)     // aksen kuning (untuk ilustrasi/penanda, bukan latar teks kecil)
val Butter = Color(0xFFFFF3DC)    // tint kuning lembut untuk kartu
val Lavender = Color(0xFFF6F0E3)  // nama lama; sekarang tint cream hangat
val Sky = Color(0xFFEEF1EA)       // nama lama; sekarang tint sage netral
val Ink = Color(0xFF292824)       // teks utama
// Brief menyarankan #716F68, tetapi kontrasnya hanya 4,28:1 di atas Mint dan 4,30:1 di atas Peach
// (di bawah 4,5:1 WCAG AA). #5F5D56 memberi 5,6-6,2:1 pada semua permukaan app.
val Soft = Color(0xFF5F5D56)      // teks sekunder
val Outline = Color(0xFFD9D5C8)   // garis tipis/divider

private val Scheme = lightColorScheme(
    primary = Sage,
    onPrimary = Color.White,
    primaryContainer = Mint,
    onPrimaryContainer = Ink,
    secondary = Sage,
    onSecondary = Color.White,
    secondaryContainer = Mint,
    onSecondaryContainer = Ink,
    tertiary = Sage,
    tertiaryContainer = Peach,
    onTertiaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Paper,
    onSurface = Ink,
    surfaceVariant = Sky,
    onSurfaceVariant = Soft,
    outline = Soft,
    outlineVariant = Outline
)

/** Radius konsisten: kartu = large (24), elemen dalam kartu = medium (16), chip/kecil = small (12). */
private val PorsiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun PorsiKecilTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Scheme,
        shapes = PorsiShapes,
        typography = PorsiTypography,
        content = content
    )
}
