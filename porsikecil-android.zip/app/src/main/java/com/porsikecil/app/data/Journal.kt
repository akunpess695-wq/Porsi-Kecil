package com.porsikecil.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class JournalEntry(
    val id: Long,
    val epochDay: Long,
    val meal: String,
    val food: String,
    val portion: String,
    val reaction: String,
    val note: String
)

val MealTypes = listOf("Sarapan", "Makan siang", "Makan malam", "Selingan")

const val ReactionAllergy = "Dugaan reaksi"

/** Nilai lama sebelum istilah diganti; dimigrasikan saat data dibaca. */
private const val LegacyReactionAllergy = "Ruam/alergi"

val Reactions = listOf("Suka", "Biasa", "Tidak suka", ReactionAllergy)

fun reactionEmoji(reaction: String): String = when (reaction) {
    "Suka" -> "😋"
    "Biasa" -> "🙂"
    "Tidak suka" -> "😖"
    else -> "⚠️"
}

fun distinctFoodCount(entries: List<JournalEntry>): Int =
    entries.map { it.food.trim().lowercase() }.distinct().size

class JournalRepository(context: Context) {
    private val prefs = context.getSharedPreferences("porsikecil_journal", Context.MODE_PRIVATE)

    /** Simpan salinan data yang gagal dibaca agar tidak hilang saat disimpan ulang. */
    private fun preserveCorrupt(key: String, raw: String) {
        prefs.edit().putString(key + "_corrupt_backup", raw).apply()
    }

    fun load(): List<JournalEntry> {
        val raw = prefs.getString("entries", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val result = ArrayList<JournalEntry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    JournalEntry(
                        id = o.getLong("id"),
                        epochDay = o.getLong("day"),
                        meal = o.optString("meal"),
                        food = o.optString("food"),
                        portion = o.optString("portion"),
                        reaction = o.optString("reaction").let { if (it == LegacyReactionAllergy) ReactionAllergy else it },
                        note = o.optString("note")
                    )
                )
            }
            result
        } catch (e: Exception) {
            preserveCorrupt("entries", raw)
            emptyList()
        }
    }

    fun save(list: List<JournalEntry>) {
        val arr = JSONArray()
        for (e in list) {
            val o = JSONObject()
            o.put("id", e.id)
            o.put("day", e.epochDay)
            o.put("meal", e.meal)
            o.put("food", e.food)
            o.put("portion", e.portion)
            o.put("reaction", e.reaction)
            o.put("note", e.note)
            arr.put(o)
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }
}
