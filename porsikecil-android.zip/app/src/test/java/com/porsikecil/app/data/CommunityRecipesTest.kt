package com.porsikecil.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CommunityRecipesTest {
    private val ideas get() = Recipes.filter { it.community != null }

    @Test fun ideaMenusExistAndAreInCombinedList() {
        assertEquals(CommunityRecipes.size, ideas.size)
        assertTrue(ideas.isNotEmpty())
    }

    @Test fun coreRecipesKeepTheirRelativeOrder() {
        val before = Recipes.filter { it.community == null }.map { it.id }
        assertEquals(21, before.size)
        assertEquals("puree-kentang-wortel", before.first())
        assertEquals("sup-ayam-sayur", before.last())
    }

    @Test fun ideaIngredientsAreNotBelowFoodListMinimumAge() {
        for (r in ideas) for (ing in r.ingredients) {
            val food = Foods.firstOrNull { it.name.equals(ing.name, ignoreCase = true) } ?: continue
            assertTrue("${r.id}: ${ing.name} mulai ${food.minMonths} bulan", food.minMonths <= r.minMonths)
        }
    }

    @Test fun ideaMenusHaveNoBannedIngredients() {
        val banned = listOf("garam", "gula", "madu", "kaldu", "penyedap", "kecap", "jeruk nipis", "kurma")
        for (r in ideas) for (ing in r.ingredients) {
            assertTrue("${r.id}: ${ing.name}", banned.none { ing.name.lowercase().contains(it) })
        }
    }

    @Test fun ideaMenusNeverBecomeRecipeOfTheDay() {
        for (months in 6..24) for (d in 0L..40L) {
            val r = recipeOfTheDay(months, LocalDate.ofEpochDay(20000 + d))
            assertFalse(r?.id ?: "", r?.community != null)
        }
    }

    @Test fun creatorCreditIsNullOrNotBlank() {
        for (r in ideas) {
            val c = r.community!!
            assertTrue(r.id, c.creator == null || c.creator.isNotBlank())
            assertTrue(r.id, c.sourceUrl == null || c.sourceUrl.isNotBlank())
        }
    }
}
