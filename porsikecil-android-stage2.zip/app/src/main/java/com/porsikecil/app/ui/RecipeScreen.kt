package com.porsikecil.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.AllergenList
import com.porsikecil.app.data.FoodCategories
import com.porsikecil.app.data.FoodItem
import com.porsikecil.app.data.Foods
import com.porsikecil.app.data.Recipe
import com.porsikecil.app.data.Recipes
import com.porsikecil.app.data.allergenSummary
import com.porsikecil.app.data.allergens
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky

private val cardColors = listOf(Peach, Mint, Lavender, Butter, Sky)

@Composable
fun RecipeScreen(
    stageMonths: Int,
    avoid: Set<String>,
    onAvoidChange: (Set<String>) -> Unit,
    favorites: Set<String>,
    onFavoritesChange: (Set<String>) -> Unit,
    onLog: (String) -> Unit
) {
    var selected by remember { mutableStateOf<Recipe?>(null) }
    var section by remember { mutableStateOf("Resep") }
    BackHandler(enabled = selected != null) { selected = null }

    val current = selected
    if (current != null) {
        RecipeDetail(
            r = current,
            stageMonths = stageMonths,
            avoid = avoid,
            onBack = { selected = null },
            onLog = { onLog(current.title) }
        )
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Resep dan Bahan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            ChipRow(listOf("Resep", "Bahan"), section) { section = it }
            if (section == "Resep") {
                RecipeList(stageMonths, avoid, onAvoidChange, favorites, onFavoritesChange, Modifier.weight(1f)) { selected = it }
            } else {
                FoodDatabase(stageMonths, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RecipeList(
    stageMonths: Int,
    avoid: Set<String>,
    onAvoidChange: (Set<String>) -> Unit,
    favorites: Set<String>,
    onFavoritesChange: (Set<String>) -> Unit,
    modifier: Modifier,
    onOpen: (Recipe) -> Unit
) {
    var onlyAge by remember { mutableStateOf(stageMonths >= 6) }
    var onlyFav by remember { mutableStateOf(false) }
    val byAge = Recipes.filter { r ->
        (!onlyAge || r.minMonths <= stageMonths) && (!onlyFav || r.id in favorites)
    }
    val shown = byAge.filter { r -> r.allergens.none { it in avoid } }
    val hidden = byAge.size - shown.size

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ChipRow(
            listOf("Sesuai usia", "Semua usia"),
            if (onlyAge) "Sesuai usia" else "Semua usia"
        ) { onlyAge = it == "Sesuai usia" }
        ChipRow(
            listOf("Semua resep", "Favorit"),
            if (onlyFav) "Favorit" else "Semua resep"
        ) { onlyFav = it == "Favorit" }

        Text("Hindari alergen (sesuai catatan Anda)", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AllergenList.forEach { a ->
                SelectChip(a, a in avoid) {
                    onAvoidChange(if (a in avoid) avoid - a else avoid + a)
                }
            }
        }
        Text(
            "Filter hanya berdasarkan daftar bahan resep. Kontaminasi silang (alat masak, kemasan) tidak termasuk, jadi tetap periksa label. Daftar enam alergen ini belum lengkap dan perlu ditinjau ahli.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (hidden > 0) {
            Text(
                "$hidden resep disembunyikan karena mengandung alergen yang Anda hindari.",
                style = MaterialTheme.typography.labelMedium
            )
        }

        if (stageMonths < 6) {
            Text(
                "Si kecil belum 6 bulan, jadi belum waktunya MPASI. Resep di bawah untuk persiapan.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (shown.isEmpty()) {
            Text(
                if (onlyFav && favorites.isEmpty()) "Belum ada resep favorit. Ketuk ikon hati pada resep."
                else "Tidak ada resep yang cocok dengan filter.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        shown.forEachIndexed { i, r ->
            RecipeCard(
                r = r,
                locked = r.minMonths > stageMonths,
                color = cardColors[i % cardColors.size],
                favorite = r.id in favorites,
                onToggleFavorite = {
                    onFavoritesChange(if (r.id in favorites) favorites - r.id else favorites + r.id)
                },
                onClick = { onOpen(r) }
            )
        }
    }
}

@Composable
private fun RecipeCard(
    r: Recipe,
    locked: Boolean,
    color: Color,
    favorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Row(
            Modifier.padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(r.emoji, fontSize = 36.sp)
            Column(Modifier.weight(1f)) {
                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${r.texture} · ±${r.minutes} menit", style = MaterialTheme.typography.bodySmall)
                Text(allergenSummary(r), style = MaterialTheme.typography.bodySmall)
                Text(
                    if (locked) "Mulai ${r.minMonths} bulan 🔒" else "Mulai ${r.minMonths} bulan",
                    style = MaterialTheme.typography.labelMedium
                )
            }
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = if (favorite) "Hapus ${r.title} dari favorit" else "Simpan ${r.title} ke favorit"
                )
            }
        }
    }
}

@Composable
private fun RecipeDetail(
    r: Recipe,
    stageMonths: Int,
    avoid: Set<String>,
    onBack: () -> Unit,
    onLog: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Kembali") }
        Text(
            "${r.emoji} ${r.title}",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Mulai usia ${r.minMonths} bulan · ${r.texture} · ±${r.minutes} menit",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (r.tags.isNotEmpty()) {
            Text(
                r.tags.joinToString(" · "),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        if (r.minMonths > stageMonths) {
            SoftCard(Peach) {
                Text("Resep ini untuk usia ${r.minMonths} bulan ke atas. Tahap makan si kecil saat ini belum sampai di sana.")
            }
        }
        SoftCard(Butter) {
            Text("⚠️ Alergen", style = MaterialTheme.typography.labelLarge)
            Text(allergenSummary(r), fontWeight = FontWeight.SemiBold)
            val hit = r.allergens.filter { it in avoid }
            if (hit.isNotEmpty()) {
                Text("Mengandung alergen yang Anda hindari: ${hit.joinToString(", ")}.")
            }
            Text(
                "Berdasarkan daftar bahan saja. Risiko kontaminasi silang tidak termasuk; periksa label kemasan. Jika anak pernah bereaksi, tanyakan ke dokter anak.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        SoftCard(Mint) {
            Text("🥕 Bahan", style = MaterialTheme.typography.labelLarge)
            r.ingredients.forEach { ing ->
                Text("• ${ing.name}: ${ing.amount}")
            }
        }
        SoftCard(Butter) {
            Text("🍳 Langkah", style = MaterialTheme.typography.labelLarge)
            r.steps.forEachIndexed { i, s ->
                Text("${i + 1}. $s")
            }
        }
        SoftCard(Peach) {
            Text("💡 Tips dan keamanan", style = MaterialTheme.typography.labelLarge)
            Text(r.tip)
            Text(
                "Tanpa tambahan garam dan gula. Ini panduan umum, bukan pengganti saran dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
            UnverifiedNote()
        }
        Button(
            onClick = onLog,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Catat ke jurnal")
        }
    }
}

@Composable
private fun FoodDatabase(stageMonths: Int, modifier: Modifier) {
    var cat by remember { mutableStateOf("Semua") }
    var query by remember { mutableStateOf("") }
    val shown = Foods.filter {
        (cat == "Semua" || it.category == cat) && it.name.contains(query.trim(), ignoreCase = true)
    }

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        UnverifiedNote()
        OutlinedTextField(
            value = query,
            onValueChange = { query = it.take(30) },
            label = { Text("Cari bahan") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        ChipRow(FoodCategories, cat) { cat = it }
        if (shown.isEmpty()) {
            Text(
                "Bahan tidak ditemukan.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        shown.forEach { f -> FoodRow(f, stageMonths) }
    }
}

@Composable
private fun FoodRow(f: FoodItem, stageMonths: Int) {
    val notYet = f.minMonths > stageMonths
    SoftCard(if (notYet) Butter else Sky) {
        Text(
            "${f.emoji} ${f.name}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(f.note, style = MaterialTheme.typography.bodySmall)
        val label = when {
            f.category == "Perhatian" -> "⚠️ Perhatian"
            notYet -> "Mulai ${f.minMonths} bulan 🔒"
            else -> "Mulai ${f.minMonths} bulan"
        }
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
