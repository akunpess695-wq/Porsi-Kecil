package com.porsikecil.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class AgeAndStageTest {
    private val today = LocalDate.of(2026, 11, 3)

    @Test fun termBabyUsesChronologicalAge() {
        val info = calculateAge(BabyProfile("A", LocalDate.of(2026, 5, 3), null), today)
        assertEquals(6, info.stageMonths)
        assertNull(info.correctedText)
        assertEquals("6 bulan", info.chronoText)
    }

    @Test fun prematureBabyUsesCorrectedAge() {
        // 32 minggu = 8 minggu lebih awal; lahir 3 Mei 2026 -> usia koreksi dihitung dari 28 Jun 2026
        val info = calculateAge(BabyProfile("A", LocalDate.of(2026, 5, 3), 32), today)
        assertNotNull(info.correctedText)
        assertEquals(4, info.stageMonths)
    }

    @Test fun correctedAgeNeverNegative() {
        val info = calculateAge(BabyProfile("A", LocalDate.of(2026, 10, 25), 24), today)
        assertEquals(0, info.stageMonths)
        assertEquals("0 hari", info.correctedText)
    }

    @Test fun periodTextFormats() {
        assertEquals("5 hari", periodText(java.time.Period.of(0, 0, 5)))
        assertEquals("3 bulan", periodText(java.time.Period.of(0, 3, 0)))
        assertEquals("1 bulan 2 hari", periodText(java.time.Period.of(0, 1, 2)))
        assertEquals("13 bulan", periodText(java.time.Period.of(1, 1, 0)))
    }

    @Test fun stageBoundaries() {
        assertEquals("Belum masuk tahap MPASI", stageFor(5).title)
        assertEquals("Tahap 1 (6 bulan)", stageFor(6).title)
        assertEquals("Tahap 2 (7–8 bulan)", stageFor(7).title)
        assertEquals("Tahap 2 (7–8 bulan)", stageFor(8).title)
        assertEquals("Tahap 3 (9–11 bulan)", stageFor(9).title)
        assertEquals("Tahap 3 (9–11 bulan)", stageFor(11).title)
        assertEquals("Tahap 4 (12 bulan ke atas)", stageFor(12).title)
    }
}
