package com.porsikecil.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.JournalEntry
import com.porsikecil.app.data.JournalRepository
import com.porsikecil.app.data.MealTypes
import com.porsikecil.app.data.PlanEntry
import com.porsikecil.app.data.PlannerRepository
import com.porsikecil.app.data.ReactionAllergy
import com.porsikecil.app.data.distinctFoodCount
import com.porsikecil.app.data.recipeOfTheDay
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.data.stageFor
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky
import java.time.LocalDate

@Composable
fun SoftCard(
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun MainScreen(
    profile: BabyProfile,
    journalRepo: JournalRepository,
    plannerRepo: PlannerRepository,
    onEditProfile: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showJournal by rememberSaveable { mutableStateOf(false) }
    var entries by remember { mutableStateOf(journalRepo.load()) }
    var draftFood by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf(plannerRepo.loadPlan()) }
    var shopping by remember { mutableStateOf(plannerRepo.loadShopping()) }
    val age = remember(profile) { calculateAge(profile) }
    val tabs = listOf(
        Icons.Filled.Home to "Beranda",
        Icons.AutoMirrored.Filled.List to "Resep",
        Icons.Filled.DateRange to "Planner",
        Icons.Filled.Info to "Edukasi",
        Icons.Filled.Person to "Profil"
    )
    BackHandler(enabled = showJournal) { showJournal = false }
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            tab = i
                            showJournal = false
                        },
                        icon = { Icon(item.first, contentDescription = null) },
                        label = { Text(item.second) }
                    )
                }
            }
        }
    ) { pad: PaddingValues ->
        Box(Modifier.padding(pad)) {
            if (showJournal) {
                Column(Modifier.fillMaxSize()) {
                    TextButton(
                        onClick = { showJournal = false },
                        modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                    ) { Text("← Kembali") }
                    Box(Modifier.weight(1f)) {
                        JournalScreen(
                            entries = entries,
                            pendingFood = draftFood,
                            onPendingHandled = { draftFood = null },
                            onAdd = { e ->
                                val updated = (entries + e).sortedWith(
                                    compareByDescending<JournalEntry> { it.epochDay }.thenByDescending { it.id }
                                )
                                entries = updated
                                journalRepo.save(updated)
                            },
                            onDelete = { e ->
                                val updated = entries.filter { it.id != e.id }
                                entries = updated
                                journalRepo.save(updated)
                            }
                        )
                    }
                }
            } else {
                when (tab) {
                    0 -> HomeScreen(
                        profile = profile,
                        entries = entries,
                        plan = plan,
                        onEditProfile = onEditProfile,
                        onOpenRecipes = { tab = 1 },
                        onOpenPlanner = { tab = 2 },
                        onOpenJournal = { showJournal = true }
                    )
                    1 -> RecipeScreen(
                        stageMonths = age.stageMonths,
                        onLog = { title ->
                            draftFood = title
                            showJournal = true
                        }
                    )
                    2 -> PlannerScreen(
                        stageMonths = age.stageMonths,
                        plan = plan,
                        onPlanChange = { updated ->
                            plan = updated
                            plannerRepo.savePlan(updated)
                        },
                        shopping = shopping,
                        onShoppingChange = { updated ->
                            shopping = updated
                            plannerRepo.saveShopping(updated)
                        }
                    )
                    3 -> ComingSoon(
                        "Edukasi", "📚", "tahap berikutnya",
                        "Materi keamanan dan gizi MPASI dengan sumber yang bisa diperiksa."
                    )
                    else -> ProfileTab(
                        profile = profile,
                        onEditProfile = onEditProfile,
                        onOpenJournal = { showJournal = true }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileTab(profile: BabyProfile, onEditProfile: () -> Unit, onOpenJournal: () -> Unit) {
    val age = remember(profile) { calculateAge(profile) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Profil", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SoftCard(Peach) {
            Text(profile.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Usia: ${age.chronoText}")
            if (age.correctedText != null) {
                Text("Usia koreksi: ${age.correctedText}")
            }
            TextButton(onClick = onEditProfile) { Text("Ubah profil") }
        }
        SoftCard(Mint) {
            Text("Jurnal makanan", style = MaterialTheme.typography.labelLarge)
            Text("Catatan menu, porsi, dan respons si kecil.")
            TextButton(onClick = onOpenJournal) { Text("Buka jurnal") }
        }
        SoftCard(Butter) {
            Text("Privasi dan batasan", style = MaterialTheme.typography.labelLarge)
            Text("• Data tersimpan hanya di perangkat ini dan tidak dikirim ke server.")
            Text("• Cadangan otomatis Android dimatikan untuk melindungi data bayi.")
            Text("• Aplikasi ini bukan alat diagnosis dan bukan pengganti dokter anak atau ahli gizi.")
        }
    }
}

@Composable
fun HomeScreen(
    profile: BabyProfile,
    entries: List<JournalEntry>,
    plan: List<PlanEntry>,
    onEditProfile: () -> Unit,
    onOpenRecipes: () -> Unit,
    onOpenPlanner: () -> Unit,
    onOpenJournal: () -> Unit
) {
    val age = remember(profile) { calculateAge(profile) }
    val stage = stageFor(age.stageMonths)
    val todayDate = LocalDate.now()
    val today = todayDate.toEpochDay()
    val todayCount = entries.count { it.epochDay == today }
    val foodCount = distinctFoodCount(entries)
    val recentAllergy = entries.any { it.reaction == ReactionAllergy && it.epochDay >= today - 7 }
    val menu = recipeOfTheDay(age.stageMonths, todayDate)
    val todayPlan = plan.filter { it.epochDay == today }.sortedBy { MealTypes.indexOf(it.meal) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Halo! 👋", style = MaterialTheme.typography.bodyLarge)
                Text(
                    profile.name,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            TextButton(onClick = onEditProfile) { Text("Ubah profil") }
        }

        SoftCard(Peach) {
            Text("👶 Usia", style = MaterialTheme.typography.labelLarge)
            Text(age.chronoText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (age.correctedText != null) {
                Text("Usia koreksi: ${age.correctedText}. Dipakai sebagai acuan tahap makan.")
            }
        }

        SoftCard(Mint) {
            Text("🥣 Tahap makan", style = MaterialTheme.typography.labelLarge)
            Text(stage.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Tekstur: ${stage.texture}")
            Text("Jadwal: ${stage.frequency}")
            Text(stage.note, style = MaterialTheme.typography.bodySmall)
            UnverifiedNote()
        }

        SoftCard(Butter) {
            Text("🍽️ Menu hari ini", style = MaterialTheme.typography.labelLarge)
            if (todayPlan.isNotEmpty()) {
                todayPlan.forEach { Text("• ${it.meal}: ${it.title}") }
                TextButton(onClick = onOpenPlanner) { Text("Buka planner") }
            } else if (menu != null) {
                Text("Saran: ${menu.emoji} ${menu.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Tekstur: ${menu.texture} · ±${menu.minutes} menit")
                TextButton(onClick = onOpenRecipes) { Text("Lihat semua resep") }
            } else {
                Text("Resep MPASI tersedia mulai usia 6 bulan. Sampai saat itu, ASI atau sufor tetap nutrisi utama.")
            }
        }

        SoftCard(Lavender) {
            Text("📝 Catat makanan", style = MaterialTheme.typography.labelLarge)
            Text("Simpan menu, porsi, dan respons si kecil di jurnal.")
            TextButton(onClick = onOpenJournal) { Text("Buka jurnal") }
        }

        SoftCard(Sky) {
            Text("📊 Ringkasan jurnal", style = MaterialTheme.typography.labelLarge)
            Text("Catatan hari ini: $todayCount")
            Text("Menu atau bahan berbeda yang sudah dicoba: $foodCount")
            if (recentAllergy) {
                Text(
                    "⚠️ Ada catatan ruam/alergi dalam 7 hari terakhir. Konsultasikan dengan dokter anak sebelum mengulang bahan tersebut.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        SoftCard(Peach) {
            Text("🛡️ Pengingat keamanan", style = MaterialTheme.typography.labelLarge)
            Text("• Jangan beri madu sebelum usia 12 bulan.")
            Text("• Tanpa tambahan garam dan gula.")
            Text("• Hindari makanan keras atau bulat utuh yang bisa membuat tersedak.")
            Text("• Kenalkan bahan baru satu per satu, tunggu 2–3 hari.")
            Text(
                "Aplikasi ini bukan pengganti dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun ComingSoon(title: String, emoji: String, sprint: String, text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 64.sp)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Segera hadir ($sprint)",
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
