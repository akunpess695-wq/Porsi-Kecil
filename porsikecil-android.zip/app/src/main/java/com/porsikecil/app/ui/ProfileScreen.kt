package com.porsikecil.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.ui.theme.Peach
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    initial: BabyProfile?,
    onBack: (() -> Unit)?,
    onSave: (BabyProfile) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var birth by remember { mutableStateOf(initial?.birthDate) }
    var premature by remember { mutableStateOf(initial?.gestationWeeks != null) }
    var weeks by remember { mutableFloatStateOf((initial?.gestationWeeks ?: 34).toFloat()) }
    var showPicker by remember { mutableStateOf(false) }

    val today = LocalDate.now()
    val b = birth
    val future = b != null && b.isAfter(today)
    val tooOld = b != null && b.isBefore(today.minusMonths(36))
    val canSave = name.isNotBlank() && b != null && !future && !tooOld
    val formatter = DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.forLanguageTag("id-ID"))

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (onBack != null) {
            BackButton(onClick = onBack)
        }
        Text(
            if (initial == null) "Kenalan dengan si kecil" else "Ubah profil bayi",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Usia dihitung otomatis dari tanggal lahir, jadi tahap makan selalu mengikuti perkembangan.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it.take(30) },
            label = { Text("Nama panggilan si kecil") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedButton(
            onClick = { showPicker = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(if (b == null) "Pilih tanggal lahir" else "Lahir: ${b.format(formatter)}")
        }
        if (future) {
            Text("Tanggal lahir tidak boleh di masa depan.", color = MaterialTheme.colorScheme.error)
        }
        if (tooOld) {
            Text("Aplikasi ini untuk bayi sampai usia 3 tahun.", color = MaterialTheme.colorScheme.error)
        }

        // Seluruh baris bisa diketuk (target >= 48 dp) dan dibaca TalkBack sebagai satu saklar.
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .toggleable(value = premature, role = Role.Switch, onValueChange = { premature = it }),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Lahir prematur?", fontWeight = FontWeight.SemiBold)
                Text(
                    "Sebelum usia kehamilan 37 minggu",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(checked = premature, onCheckedChange = null)
        }
        if (premature) {
            Text("Usia kehamilan saat lahir: ${weeks.roundToInt()} minggu")
            Slider(
                value = weeks,
                onValueChange = { weeks = it },
                valueRange = 24f..36f,
                steps = 11,
                modifier = Modifier.semantics { contentDescription = "Usia kehamilan saat lahir, minggu" }
            )
            Text(
                "Panduan umum aplikasi mungkin tidak sesuai untuk bayi prematur. Tahap dan kesiapan makan perlu ditentukan bersama dokter atau ahli gizi anak.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (b != null && canSave) {
            val age = calculateAge(
                BabyProfile(name.trim(), b, if (premature) weeks.roundToInt() else null)
            )
            PkCard(color = Peach) {
                Text("Usia saat ini", style = MaterialTheme.typography.labelLarge)
                Text(age.chronoText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (age.correctedText != null) {
                    Text("Usia koreksi: ${age.correctedText}")
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                val date = birth
                if (date != null) {
                    onSave(BabyProfile(name.trim(), date, if (premature) weeks.roundToInt() else null))
                }
            },
            enabled = canSave,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Simpan")
        }
    }

    if (showPicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = birth?.atStartOfDay(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { ms ->
                        birth = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    showPicker = false
                }) { Text("Pilih") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Batal") }
            }
        ) {
            DatePicker(state = pickerState)
        }
    }
}
