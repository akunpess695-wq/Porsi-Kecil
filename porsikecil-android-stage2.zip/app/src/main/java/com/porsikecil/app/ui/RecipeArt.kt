package com.porsikecil.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.porsikecil.app.R
import com.porsikecil.app.data.Recipe
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky

/** Ilustrasi + warna latar + deskripsi TalkBack untuk satu resep. Murni UI; tidak mengubah data resep. */
data class RecipeArtSpec(@DrawableRes val res: Int, val tint: Color, val description: String)

/**
 * Pemetaan id resep -> ilustrasi lokal. Resep yang belum punya ilustrasi khusus memakai mangkuk
 * (placeholder konsisten). Foto makanan asli bisa menggantikan ini nanti tanpa mengubah pemanggil.
 */
fun recipeArt(r: Recipe): RecipeArtSpec = when (r.id) {
    "puree-kentang-wortel" -> RecipeArtSpec(R.drawable.ill_potato, Peach, "Ilustrasi kentang")
    "puree-alpukat-pisang" -> RecipeArtSpec(R.drawable.ill_avocado, Mint, "Ilustrasi alpukat")
    "puree-ubi-labu", "tahu-labu-lembut" -> RecipeArtSpec(R.drawable.ill_pumpkin, Butter, "Ilustrasi labu")
    "bubur-ikan-brokoli" -> RecipeArtSpec(R.drawable.ill_fish, Sky, "Ilustrasi ikan")
    "bubur-ikan-bayam", "tim-salmon-labu" -> RecipeArtSpec(R.drawable.ill_fish, Sky, "Ilustrasi ikan")
    "telur-orak-arik", "telur-kukus-lembut" -> RecipeArtSpec(R.drawable.ill_egg, Butter, "Ilustrasi telur")
    "perkedel-tahu-wortel" -> RecipeArtSpec(R.drawable.ill_carrot, Peach, "Ilustrasi wortel")
    else -> RecipeArtSpec(R.drawable.ill_bowl, Mint, "Ilustrasi mangkuk makanan")
}
