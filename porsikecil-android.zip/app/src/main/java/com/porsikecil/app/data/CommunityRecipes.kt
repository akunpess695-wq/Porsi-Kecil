package com.porsikecil.app.data

/**
 * IDE MENU. Draf resep tambahan di luar daftar inti.
 *
 * - Disusun PorsiKecil dari bahan yang sudah ada di daftar Bahan (usia mengikuti daftar itu),
 *   tanpa garam, gula, atau madu. BUKAN kutipan dari orang tua atau sumber lain.
 * - Belum ditinjau dokter anak atau ahli gizi. Tinjau bahan, takaran, usia, dan tekstur sebelum rilis.
 * - Untuk menambahkan resep dari orang tua sungguhan: isi [CommunityInfo.creator] dan [CommunityInfo.sourceUrl]
 *   hanya jika kreatornya memberi izin; tulis ulang dengan kata-kata sendiri, jangan salin teks aslinya.
 * - Urutan di sini bebas; [Recipes] mengurutkan berdasarkan usia minimum.
 */
internal val CommunityRecipes = listOf(
    Recipe(
        id = "ide-puree-pepaya-pir",
        title = "Puree Pepaya Pir",
        emoji = "",
        minMonths = 6,
        texture = "Halus",
        minutes = 15,
        tags = listOf("Buah", "Tanpa masak sebagian"),
        ingredients = listOf(
            RecipeIngredient("Pir", "40 g"),
            RecipeIngredient("Pepaya", "40 g"),
            RecipeIngredient("ASI atau air matang", "1–2 sdm")
        ),
        steps = listOf(
            "Kupas pir, buang bijinya, lalu kukus sampai sangat empuk.",
            "Kupas pepaya yang sudah matang, buang bijinya.",
            "Haluskan pir dan pepaya dengan blender atau saringan.",
            "Tambahkan ASI atau air matang sedikit demi sedikit sampai kekentalan pas. Sajikan segera."
        ),
        tip = "Pilih pepaya yang matang benar. Perhatikan reaksi anak setiap kali mengenalkan bahan baru.",
        community = CommunityInfo()
    ),
    Recipe(
        id = "ide-oat-pir-lembut",
        title = "Oat Pir Lembut",
        emoji = "",
        minMonths = 6,
        texture = "Halus",
        minutes = 20,
        tags = listOf("Sarapan", "Buah"),
        ingredients = listOf(
            RecipeIngredient("Oat", "15 g"),
            RecipeIngredient("Pir", "40 g"),
            RecipeIngredient("Air matang", "100 ml")
        ),
        steps = listOf(
            "Kukus pir sampai empuk, lalu lumatkan.",
            "Masak oat dengan air matang sambil diaduk sampai sangat lembut.",
            "Haluskan oat dengan blender bila masih kasar.",
            "Campur oat dengan pir, aduk rata, sajikan hangat."
        ),
        tip = "Pilih oat polos tanpa gula atau perisa.",
        community = CommunityInfo()
    ),
    Recipe(
        id = "ide-bubur-labu-ayam",
        title = "Bubur Labu Ayam",
        emoji = "",
        minMonths = 6,
        texture = "Halus (saring)",
        minutes = 40,
        tags = listOf("Protein hewani", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Beras", "20 g"),
            RecipeIngredient("Labu kuning", "30 g"),
            RecipeIngredient("Daging ayam", "20 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Minyak zaitun", "½ sdt")
        ),
        steps = listOf(
            "Rebus ayam tanpa kulit sampai matang sempurna, lalu suwir.",
            "Masak beras dengan air sampai menjadi bubur lembek.",
            "Masukkan labu yang sudah dipotong kecil dan ayam, masak sampai sangat lunak.",
            "Blender lalu saring sampai halus. Tambahkan minyak zaitun, aduk rata."
        ),
        tip = "Pastikan ayam matang sempurna dan tanpa kulit.",
        community = CommunityInfo()
    ),
    Recipe(
        id = "ide-bubur-tahu-tomat",
        title = "Bubur Tahu Tomat",
        emoji = "",
        minMonths = 7,
        texture = "Lumat",
        minutes = 30,
        tags = listOf("Nabati", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Beras", "20 g"),
            RecipeIngredient("Tahu", "25 g"),
            RecipeIngredient("Tomat", "20 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Minyak zaitun", "½ sdt")
        ),
        steps = listOf(
            "Masak beras dengan air sampai menjadi bubur lembek.",
            "Seduh tomat dengan air panas, kupas kulitnya, buang bijinya, lalu cincang halus.",
            "Masukkan tahu dan tomat ke bubur, masak sekitar 5 menit sampai lunak.",
            "Lumatkan dengan garpu atau blender kasar. Tambahkan minyak zaitun, aduk rata."
        ),
        tip = "Tomat bisa terasa asam. Campurkan dengan bahan lain dan perhatikan reaksi anak.",
        community = CommunityInfo()
    ),
    Recipe(
        id = "ide-bubur-ubi-tempe",
        title = "Bubur Ubi Tempe",
        emoji = "",
        minMonths = 7,
        texture = "Lumat",
        minutes = 35,
        tags = listOf("Nabati", "Vitamin A"),
        ingredients = listOf(
            RecipeIngredient("Ubi jalar", "30 g"),
            RecipeIngredient("Tempe", "20 g"),
            RecipeIngredient("Beras", "15 g"),
            RecipeIngredient("Air", "250 ml")
        ),
        steps = listOf(
            "Kukus tempe sekitar 10 menit sebelum diolah.",
            "Kupas ubi jalar, potong kecil-kecil.",
            "Masak beras, ubi, dan tempe dengan air sampai semuanya sangat lunak.",
            "Lumatkan sampai tidak ada potongan keras, sajikan hangat."
        ),
        tip = "Kukus tempe dulu sebelum diolah, lalu haluskan.",
        community = CommunityInfo()
    ),
    Recipe(
        id = "ide-tim-ikan-buncis",
        title = "Tim Ikan Kembung Buncis",
        emoji = "",
        minMonths = 8,
        texture = "Tim kasar",
        minutes = 40,
        tags = listOf("Protein hewani", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Beras", "25 g"),
            RecipeIngredient("Ikan kembung", "25 g"),
            RecipeIngredient("Buncis", "15 g"),
            RecipeIngredient("Wortel", "15 g"),
            RecipeIngredient("Air", "200 ml"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kukus ikan sampai matang. Periksa duri dengan teliti, termasuk duri halus, lalu suwir kecil.",
            "Masak beras dengan air sampai lembek seperti tim.",
            "Rebus buncis dan wortel sampai sangat empuk, lalu cincang halus.",
            "Campur nasi tim, ikan, dan sayur, masak sebentar. Tambahkan minyak zaitun, aduk rata."
        ),
        tip = "Periksa duri ikan dengan teliti sebelum disajikan.",
        community = CommunityInfo()
    )
)
