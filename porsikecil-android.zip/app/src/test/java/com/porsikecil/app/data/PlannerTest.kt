package com.porsikecil.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PlannerTest {
    private fun entry(id: Long, recipe: String) = PlanEntry(id, 0, "Sarapan", recipe, recipe)

    @Test fun weekStartIsMonday() {
        assertEquals(LocalDate.of(2026, 11, 2), weekStart(LocalDate.of(2026, 11, 3)))
        assertEquals(LocalDate.of(2026, 11, 2), weekStart(LocalDate.of(2026, 11, 8)))
        assertEquals(LocalDate.of(2026, 11, 2), weekStart(LocalDate.of(2026, 11, 2)))
    }

    @Test fun shoppingSumsGramsAndSkipsWaterAndAsi() {
        val list = buildShoppingFromPlan(
            listOf(entry(1, "puree-kentang-wortel"), entry(2, "bubur-ayam-wortel"))
        ).toMap()
        assertEquals("60 g", list["Kentang"])
        assertEquals("70 g", list["Wortel"]) // 40 + 30
        assertFalse(list.keys.any { it.startsWith("Air") || it.contains("ASI") })
    }

    @Test fun shoppingKeepsNonMetricAmountsAsText() {
        val list = buildShoppingFromPlan(
            listOf(entry(1, "telur-orak-arik"), entry(2, "perkedel-tahu-wortel"))
        ).toMap()
        assertEquals("1 butir + ½ butir", list["Telur"])
    }

    @Test fun shoppingIgnoresCustomMenu() {
        assertTrue(buildShoppingFromPlan(listOf(entry(1, ""))).isEmpty())
    }

    @Test fun mergeKeepsManualItemsAndCheckedState() {
        val existing = listOf(
            ShoppingItem(1, "Sabun", "", true, false),
            ShoppingItem(2, "Kentang", "60 g", true, true),
            ShoppingItem(3, "Telur", "1 butir", false, true)
        )
        val merged = mergeShopping(existing, listOf("Kentang" to "120 g", "Tahu" to "50 g"))
        assertTrue(merged.any { it.name == "Sabun" && !it.auto && it.checked })
        assertTrue(merged.first { it.name == "Kentang" }.checked)
        assertFalse(merged.first { it.name == "Tahu" }.checked)
        assertFalse(merged.any { it.name == "Telur" })
        assertEquals(merged.size, merged.map { it.id }.distinct().size)
    }

    @Test fun newIdIsUniqueAndIncreasing() {
        val ids = List(1000) { newId() }
        assertEquals(1000, ids.distinct().size)
        assertEquals(ids, ids.sorted())
    }
}
