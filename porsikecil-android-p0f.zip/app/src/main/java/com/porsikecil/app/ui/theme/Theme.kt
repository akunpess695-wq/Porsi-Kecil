package com.porsikecil.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Sage = Color(0xFF3F6B4E)
val Peach = Color(0xFFFDEDE3)
val Mint = Color(0xFFE6EEE3)
val Lavender = Color(0xFFF6F0E3)
val Butter = Color(0xFFFFF3DC)
val Sky = Color(0xFFEEF1EA)
val Ink = Color(0xFF2B2623)
val Soft = Color(0xFF6B625C)
val Paper = Color(0xFFFCF9F3)

private val Scheme = lightColorScheme(
    primary = Sage,
    onPrimary = Color.White,
    primaryContainer = Peach,
    onPrimaryContainer = Ink,
    secondary = Sage,
    secondaryContainer = Mint,
    onSecondaryContainer = Ink,
    tertiary = Sage,
    tertiaryContainer = Lavender,
    onTertiaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Paper,
    onSurface = Ink,
    surfaceVariant = Sky,
    onSurfaceVariant = Soft
)

private val CuteShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun PorsiKecilTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, shapes = CuteShapes, content = content)
}
