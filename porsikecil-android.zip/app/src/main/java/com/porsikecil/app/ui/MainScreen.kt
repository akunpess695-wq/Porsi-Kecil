package com.porsikecil.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.BabyProfile
import com.porsikecil.app.data.JournalEntry
import com.porsikecil.app.data.JournalRepository
import com.porsikecil.app.data.ReactionAllergy
import com.porsikecil.app.data.distinctFoodCount
import com.porsikecil.app.data.recipeOfTheDay
import com.porsikecil.app.data.calculateAge
import com.porsikecil.app.data.stageFor
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky
import java.time.LocalDate

@Composable
fun SoftCard(
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Column(
            Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun MainScreen(profile: BabyProfile, journalRepo: JournalRepository, onEditProfile: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var entries by remember { mutableStateOf(journalRepo.load()) }
    var draftFood by remember { mutableStateOf<String?>(null) }
    val age = remember(profile) { calculateAge(profile) }
    val tabs = listOf(
        "🏠" to "Beranda",
        "📖" to "Resep",
        "✨" to "AI",
        "📅" to "Planner",
        "📝" to "Jurnal"
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(item.first, fontSize = 22.sp) },
                        label = { Text(item.second) }
                    )
                }
            }
        }
    ) { pad: PaddingValues ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(
                    profile = profile,
                    entries = entries,
                    onEditProfile = onEditProfile,
                    onOpenRecipes = { tab = 1 }
                )
                1 -> RecipeScreen(
                    stageMonths = age.stageMonths,
                    onLog = { title ->
                        draftFood = title
                        tab = 4
                    }
                )
                2 -> ComingSoon("AI Assistant", "✨", "Sprint 4", "Menu dari bahan di rumah dan tanya jawab nutrisi.")
                3 -> ComingSoon("Planner", "📅", "Sprint 5", "Kalender menu mingguan dan daftar belanja otomatis.")
                else -> JournalScreen(
                    entries = entries,
                    pendingFood = draftFood,
                    onPendingHandled = { draftFood = null },
                    onAdd = { e ->
                        val updated = (entries + e).sortedWith(
                            compareByDescending<JournalEntry> { it.epochDay }.thenByDescending { it.id }
                        )
                        entries = updated
                        journalRepo.save(updated)
                    },
                    onDelete = { e ->
                        val updated = entries.filter { it.id != e.id }
                        entries = updated
                        journalRepo.save(updated)
                    }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    profile: BabyProfile,
    entries: List<JournalEntry>,
    onEditProfile: () -> Unit,
    onOpenRecipes: () -> Unit
) {
    val age = remember(profile) { calculateAge(profile) }
    val stage = stageFor(age.stageMonths)
    val todayDate = LocalDate.now()
    val today = todayDate.toEpochDay()
    val todayCount = entries.count { it.epochDay == today }
    val foodCount = distinctFoodCount(entries)
    val recentAllergy = entries.any { it.reaction == ReactionAllergy && it.epochDay >= today - 7 }
    val menu = recipeOfTheDay(age.stageMonths, todayDate)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Halo! 👋", style = MaterialTheme.typography.bodyLarge)
                Text(
                    profile.name,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            TextButton(onClick = onEditProfile) { Text("Ubah profil") }
        }

        SoftCard(Peach) {
            Text("👶 Usia", style = MaterialTheme.typography.labelLarge)
            Text(age.chronoText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (age.correctedText != null) {
                Text("Usia koreksi: ${age.correctedText}. Dipakai sebagai acuan tahap makan.")
            }
        }

        SoftCard(Mint) {
            Text("🥣 Tahap makan", style = MaterialTheme.typography.labelLarge)
            Text(stage.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Tekstur: ${stage.texture}")
            Text("Jadwal: ${stage.frequency}")
            Text(stage.note, style = MaterialTheme.typography.bodySmall)
        }

        SoftCard(Butter) {
            Text("🍽️ Menu hari ini", style = MaterialTheme.typography.labelLarge)
            if (menu != null) {
                Text("${menu.emoji} ${menu.title}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Tekstur: ${menu.texture} · ±${menu.minutes} menit")
                TextButton(onClick = onOpenRecipes) { Text("Lihat semua resep") }
            } else {
                Text("Resep MPASI tersedia mulai usia 6 bulan. Sampai saat itu, ASI atau sufor tetap nutrisi utama.")
            }
        }

        SoftCard(Lavender) {
            Text("✨ Tanya AI", style = MaterialTheme.typography.labelLarge)
            Text("Menu dari bahan di rumah dan saran nutrisi (Sprint 4).")
        }

        SoftCard(Sky) {
            Text("📊 Ringkasan jurnal", style = MaterialTheme.typography.labelLarge)
            Text("Catatan hari ini: $todayCount")
            Text("Menu atau bahan berbeda yang sudah dicoba: $foodCount")
            if (recentAllergy) {
                Text(
                    "⚠️ Ada catatan ruam/alergi dalam 7 hari terakhir. Konsultasikan dengan dokter anak sebelum mengulang bahan tersebut.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        SoftCard(Peach) {
            Text("🛡️ Pengingat keamanan", style = MaterialTheme.typography.labelLarge)
            Text("• Jangan beri madu sebelum usia 12 bulan.")
            Text("• Tanpa tambahan garam dan gula.")
            Text("• Hindari makanan keras atau bulat utuh yang bisa membuat tersedak.")
            Text("• Kenalkan bahan baru satu per satu, tunggu 2–3 hari.")
            Text(
                "Aplikasi ini bukan pengganti dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun ComingSoon(title: String, emoji: String, sprint: String, text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 64.sp)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Segera hadir ($sprint)",
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
