package com.porsikecil.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Coral = Color(0xFFC4694F)
val Peach = Color(0xFFFDEDE3)
val Mint = Color(0xFFE6F0E1)
val MintDark = Color(0xFF4F7A5A)
val Lavender = Color(0xFFEFE9F8)
val LavenderDark = Color(0xFF6B4FA3)
val Butter = Color(0xFFFFF1D6)
val Sky = Color(0xFFE3EFF4)
val Ink = Color(0xFF2B2623)
val Soft = Color(0xFF6F6560)
val Paper = Color(0xFFFCFAF8)

private val Scheme = lightColorScheme(
    primary = Coral,
    onPrimary = Color.White,
    primaryContainer = Peach,
    onPrimaryContainer = Ink,
    secondary = MintDark,
    secondaryContainer = Mint,
    onSecondaryContainer = Ink,
    tertiary = LavenderDark,
    tertiaryContainer = Lavender,
    onTertiaryContainer = Ink,
    background = Paper,
    onBackground = Ink,
    surface = Paper,
    onSurface = Ink,
    surfaceVariant = Sky,
    onSurfaceVariant = Soft
)

private val CuteShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun PorsiKecilTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, shapes = CuteShapes, content = content)
}
