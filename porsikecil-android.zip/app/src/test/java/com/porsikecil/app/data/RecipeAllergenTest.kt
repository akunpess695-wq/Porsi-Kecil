package com.porsikecil.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class RecipeAllergenTest {
    private fun recipe(id: String) = Recipes.first { it.id == id }

    @Test fun detectsAllergensFromIngredients() {
        assertEquals(listOf("Telur", "Kedelai"), recipe("perkedel-tahu-wortel").allergens)
        assertEquals(listOf("Telur", "Susu sapi"), recipe("pancake-pisang-oat").allergens)
        assertTrue(recipe("bubur-ikan-brokoli").allergens.contains("Ikan"))
        assertTrue(recipe("bubur-hati-bayam").allergens.contains("Susu sapi"))
    }

    @Test fun recipeWithoutKnownAllergenIsEmptyAndWorded() {
        val r = recipe("puree-kentang-wortel")
        assertTrue(r.allergens.isEmpty())
        assertTrue(allergenSummary(r).contains("tidak terdeteksi"))
    }

    @Test fun allergensAreAlwaysFromKnownList() {
        for (r in Recipes) assertTrue(r.id, AllergenList.containsAll(r.allergens))
    }

    @Test fun recipeIdsAreUnique() {
        assertEquals(Recipes.size, Recipes.map { it.id }.distinct().size)
    }

    @Test fun recipeOfTheDayRespectsAvoidedAllergens() {
        val avoid = setOf("Telur", "Ikan")
        for (d in 0L..60L) {
            val r = recipeOfTheDay(12, LocalDate.ofEpochDay(20000 + d), avoid)
            assertFalse(r == null)
            assertTrue(r!!.allergens.none { it in avoid })
        }
    }

    @Test fun recipeOfTheDayWithAllAvoidedOnlyOffersAllergenFreeRecipes() {
        val r = recipeOfTheDay(12, LocalDate.of(2026, 11, 3), AllergenList.toSet())
        assertTrue(r == null || r.allergens.isEmpty())
    }

    @Test fun japaneseStyleRecipesUseLocalSimpleIngredients() {
        val jp = Recipes.filter { "Gaya Jepang" in it.tags }
        assertEquals(4, jp.size)
        val banned = listOf("kecap", "miso", "dashi", "kaldu instan", "penyedap")
        for (r in jp) {
            for (ing in r.ingredients) {
                assertTrue("${r.id}: ${ing.name}", banned.none { ing.name.lowercase().contains(it) })
            }
        }
        assertTrue(recipe("telur-kukus-lembut").allergens.contains("Telur"))
        assertTrue(recipe("tahu-labu-lembut").allergens.contains("Kedelai"))
        assertTrue(recipe("bubur-ikan-bayam").allergens.contains("Ikan"))
        assertTrue(recipe("okayu-bayi").allergens.isEmpty())
    }

    @Test fun recipesAreOrderedByMinimumAge() {
        val ages = Recipes.map { it.minMonths }
        assertEquals(ages.sorted(), ages)
    }
}
