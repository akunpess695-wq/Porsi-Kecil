package com.porsikecil.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.porsikecil.app.data.BabyRepository
import com.porsikecil.app.data.JournalRepository
import com.porsikecil.app.data.PlannerRepository

@Composable
fun PorsiKecilApp() {
    val context = LocalContext.current
    val repo = remember { BabyRepository(context) }
    val journalRepo = remember { JournalRepository(context) }
    val plannerRepo = remember { PlannerRepository(context) }
    var profile by remember { mutableStateOf(repo.load()) }
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen(onDone = {
                val dest = when {
                    !repo.onboardingDone() -> "onboarding"
                    profile == null -> "profile_new"
                    else -> "main"
                }
                nav.navigate(dest) { popUpTo("splash") { inclusive = true } }
            })
        }
        composable("onboarding") {
            OnboardingScreen(onFinish = {
                repo.setOnboardingDone()
                val dest = if (profile == null) "profile_new" else "main"
                nav.navigate(dest) { popUpTo("onboarding") { inclusive = true } }
            })
        }
        composable("profile_new") {
            ProfileScreen(
                initial = null,
                onBack = null,
                onSave = { p ->
                    repo.save(p)
                    profile = p
                    nav.navigate("main") { popUpTo("profile_new") { inclusive = true } }
                }
            )
        }
        composable("profile_edit") {
            ProfileScreen(
                initial = profile,
                onBack = { nav.popBackStack() },
                onSave = { p ->
                    repo.save(p)
                    profile = p
                    nav.popBackStack()
                }
            )
        }
        composable("main") {
            val p = profile
            if (p != null) {
                MainScreen(
                    profile = p,
                    journalRepo = journalRepo,
                    plannerRepo = plannerRepo,
                    onEditProfile = { nav.navigate("profile_edit") }
                )
            }
        }
    }
}
