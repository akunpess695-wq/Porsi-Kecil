package com.porsikecil.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.porsikecil.app.data.FoodCategories
import com.porsikecil.app.data.FoodItem
import com.porsikecil.app.data.Foods
import com.porsikecil.app.data.Recipe
import com.porsikecil.app.data.Recipes
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Ink
import com.porsikecil.app.ui.theme.Lavender
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import com.porsikecil.app.ui.theme.Sky

private val cardColors = listOf(Peach, Mint, Lavender, Butter, Sky)

@Composable
fun RecipeScreen(stageMonths: Int, onLog: (String) -> Unit) {
    var selected by remember { mutableStateOf<Recipe?>(null) }
    var section by remember { mutableStateOf("Resep") }
    BackHandler(enabled = selected != null) { selected = null }

    val current = selected
    if (current != null) {
        RecipeDetail(
            r = current,
            stageMonths = stageMonths,
            onBack = { selected = null },
            onLog = { onLog(current.title) }
        )
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "Resep dan Bahan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            ChipRow(listOf("Resep", "Bahan"), section) { section = it }
            if (section == "Resep") {
                RecipeList(stageMonths, Modifier.weight(1f)) { selected = it }
            } else {
                FoodDatabase(stageMonths, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RecipeList(stageMonths: Int, modifier: Modifier, onOpen: (Recipe) -> Unit) {
    var onlyAge by remember { mutableStateOf(stageMonths >= 6) }
    val shown = if (onlyAge) Recipes.filter { it.minMonths <= stageMonths } else Recipes

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ChipRow(
            listOf("Sesuai usia", "Semua usia"),
            if (onlyAge) "Sesuai usia" else "Semua usia"
        ) { onlyAge = it == "Sesuai usia" }

        if (stageMonths < 6) {
            Text(
                "Si kecil belum 6 bulan, jadi belum waktunya MPASI. Resep di bawah untuk persiapan.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        shown.forEachIndexed { i, r ->
            RecipeCard(
                r = r,
                locked = r.minMonths > stageMonths,
                color = cardColors[i % cardColors.size],
                onClick = { onOpen(r) }
            )
        }
    }
}

@Composable
private fun RecipeCard(r: Recipe, locked: Boolean, color: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = color, contentColor = Ink)
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(r.emoji, fontSize = 36.sp)
            Column(Modifier.weight(1f)) {
                Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${r.texture} · ±${r.minutes} menit", style = MaterialTheme.typography.bodySmall)
                Text(
                    if (locked) "Mulai ${r.minMonths} bulan 🔒" else "Mulai ${r.minMonths} bulan",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
private fun RecipeDetail(r: Recipe, stageMonths: Int, onBack: () -> Unit, onLog: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Kembali") }
        Text(
            "${r.emoji} ${r.title}",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Mulai usia ${r.minMonths} bulan · ${r.texture} · ±${r.minutes} menit",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (r.tags.isNotEmpty()) {
            Text(
                r.tags.joinToString(" · "),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        if (r.minMonths > stageMonths) {
            SoftCard(Peach) {
                Text("Resep ini untuk usia ${r.minMonths} bulan ke atas. Tahap makan si kecil saat ini belum sampai di sana.")
            }
        }
        SoftCard(Mint) {
            Text("🥕 Bahan", style = MaterialTheme.typography.labelLarge)
            r.ingredients.forEach { ing ->
                Text("• ${ing.name}: ${ing.amount}")
            }
        }
        SoftCard(Butter) {
            Text("🍳 Langkah", style = MaterialTheme.typography.labelLarge)
            r.steps.forEachIndexed { i, s ->
                Text("${i + 1}. $s")
            }
        }
        SoftCard(Peach) {
            Text("💡 Tips dan keamanan", style = MaterialTheme.typography.labelLarge)
            Text(r.tip)
            Text(
                "Tanpa tambahan garam dan gula. Ini panduan umum, bukan pengganti saran dokter anak atau ahli gizi.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Button(
            onClick = onLog,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text("Catat ke jurnal")
        }
    }
}

@Composable
private fun FoodDatabase(stageMonths: Int, modifier: Modifier) {
    var cat by remember { mutableStateOf("Semua") }
    var query by remember { mutableStateOf("") }
    val shown = Foods.filter {
        (cat == "Semua" || it.category == cat) && it.name.contains(query.trim(), ignoreCase = true)
    }

    Column(
        modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it.take(30) },
            label = { Text("Cari bahan") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        ChipRow(FoodCategories, cat) { cat = it }
        if (shown.isEmpty()) {
            Text(
                "Bahan tidak ditemukan.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        shown.forEach { f -> FoodRow(f, stageMonths) }
    }
}

@Composable
private fun FoodRow(f: FoodItem, stageMonths: Int) {
    val notYet = f.minMonths > stageMonths
    SoftCard(if (notYet) Butter else Sky) {
        Text(
            "${f.emoji} ${f.name}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(f.note, style = MaterialTheme.typography.bodySmall)
        val label = when {
            f.category == "Perhatian" -> "⚠️ Perhatian"
            notYet -> "Mulai ${f.minMonths} bulan 🔒"
            else -> "Mulai ${f.minMonths} bulan"
        }
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
