package com.porsikecil.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.porsikecil.app.data.JournalEntry
import com.porsikecil.app.data.MealTypes
import com.porsikecil.app.data.newId
import com.porsikecil.app.data.ReactionAllergy
import com.porsikecil.app.data.Reactions
import com.porsikecil.app.data.reactionEmoji
import com.porsikecil.app.ui.theme.Butter
import com.porsikecil.app.ui.theme.Mint
import com.porsikecil.app.ui.theme.Peach
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun JournalScreen(
    entries: List<JournalEntry>,
    pendingFood: String?,
    onPendingHandled: () -> Unit,
    onAdd: (JournalEntry) -> Unit,
    onDelete: (JournalEntry) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var initialFood by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<JournalEntry?>(null) }
    val formatter = remember {
        DateTimeFormatter.ofPattern("d MMM yyyy", Locale.forLanguageTag("id-ID"))
    }

    LaunchedEffect(pendingFood) {
        if (pendingFood != null) {
            initialFood = pendingFood
            showAdd = true
            onPendingHandled()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Jurnal Makanan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                initialFood = ""
                showAdd = true
            }) { Text("+ Catat") }
        }
        Spacer(Modifier.height(12.dp))
        if (entries.isEmpty()) {
            SoftCard(Butter) {
                Text("Belum ada catatan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Catat menu, porsi, dan respons si kecil. Dari sini terlihat bahan apa yang sudah dicoba dan mana yang menimbulkan reaksi.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries, key = { it.id }) { e ->
                    JournalCard(e, formatter) { toDelete = e }
                }
            }
        }
    }

    if (showAdd) {
        AddJournalDialog(
            initialFood = initialFood,
            onDismiss = { showAdd = false },
            onSave = { e ->
                onAdd(e)
                showAdd = false
            }
        )
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Hapus catatan?") },
            text = { Text("Catatan \"${del.food}\" akan dihapus dari jurnal.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(del)
                    toDelete = null
                }) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun JournalCard(e: JournalEntry, formatter: DateTimeFormatter, onDelete: () -> Unit) {
    val isAllergy = e.reaction == ReactionAllergy
    SoftCard(if (isAllergy) Peach else Mint) {
        Text(
            "${LocalDate.ofEpochDay(e.epochDay).format(formatter)} · ${e.meal}",
            style = MaterialTheme.typography.labelLarge
        )
        Text(e.food, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (e.portion.isNotBlank()) {
            Text("Porsi: ${e.portion}")
        }
        Text("${reactionEmoji(e.reaction)} ${e.reaction}")
        if (e.note.isNotBlank()) {
            Text(e.note, style = MaterialTheme.typography.bodySmall)
        }
        if (isAllergy) {
            Text(
                "Jika ada bengkak di bibir atau wajah, sulit bernapas, atau muntah berulang, segera ke IGD. Untuk ruam ringan, konsultasikan ke dokter anak sebelum mengulang bahan ini.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        TextButton(onClick = onDelete) { Text("Hapus") }
    }
}

@Composable
private fun AddJournalDialog(
    initialFood: String,
    onDismiss: () -> Unit,
    onSave: (JournalEntry) -> Unit
) {
    var food by remember { mutableStateOf(initialFood) }
    var portion by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var meal by remember { mutableStateOf(MealTypes[0]) }
    var reaction by remember { mutableStateOf(Reactions[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat makanan") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = food,
                    onValueChange = { food = it.take(60) },
                    label = { Text("Menu atau bahan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Waktu makan", style = MaterialTheme.typography.labelLarge)
                ChipRow(MealTypes, meal) { meal = it }
                OutlinedTextField(
                    value = portion,
                    onValueChange = { portion = it.take(30) },
                    label = { Text("Porsi (misal 3 sdm)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Respons si kecil", style = MaterialTheme.typography.labelLarge)
                ChipRow(Reactions, reaction) { reaction = it }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(120) },
                    label = { Text("Catatan (opsional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = food.isNotBlank(),
                onClick = {
                    onSave(
                        JournalEntry(
                            id = newId(),
                            epochDay = LocalDate.now().toEpochDay(),
                            meal = meal,
                            food = food.trim(),
                            portion = portion.trim(),
                            reaction = reaction,
                            note = note.trim()
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
