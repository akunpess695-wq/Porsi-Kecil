package com.porsikecil.app.data

import android.content.Context

/** Preferensi pengguna: alergen yang dihindari (catatan pengguna) dan resep favorit. */
class UserPrefsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("porsikecil_prefs", Context.MODE_PRIVATE)

    fun loadAvoid(): Set<String> = prefs.getStringSet("avoid", emptySet())?.toSet() ?: emptySet()

    fun saveAvoid(v: Set<String>) {
        prefs.edit().putStringSet("avoid", v.toSet()).apply()
    }

    fun loadFavorites(): Set<String> = prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()

    fun saveFavorites(v: Set<String>) {
        prefs.edit().putStringSet("favorites", v.toSet()).apply()
    }
}
