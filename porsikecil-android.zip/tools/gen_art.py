"""Generator ilustrasi PorsiKecil: satu sumber -> Android VectorDrawable (+ SVG untuk pratinjau).
Gaya: bentuk bulat sederhana, palet terbatas, outline halus warna gelap hangat."""
import os, sys
OUT = sys.argv[1]; PREV = sys.argv[2]
LINE = "#5A4A3F"   # outline hangat
CREAM="#FFF7EA"; SAGE="#8DB596"; SAGED="#426B55"; PEACH="#F7C9B0"; HONEY="#F4D98B"
ORANGE="#F2A15F"; GREEN="#7DB07F"; GREEN2="#5E9A6B"; AVO="#C9DB8A"; AVOD="#7FA55A"; BROWN="#B98A63"
SKIN="#F8D5BC"; RED="#E88E7A"; BLUE="#9FC3D8"; WHITE="#FFFFFF"; PUMP="#F0B36B"; EGG="#FFFDF5"; YOLK="#F4C95D"

def circ(cx,cy,r): return f"M{cx-r},{cy} a{r},{r} 0 1,0 {2*r},0 a{r},{r} 0 1,0 {-2*r},0 z"
def ell(cx,cy,rx,ry): return f"M{cx-rx},{cy} a{rx},{ry} 0 1,0 {2*rx},0 a{rx},{ry} 0 1,0 {-2*rx},0 z"
def rr(x,y,w,h,r): return f"M{x+r},{y} h{w-2*r} a{r},{r} 0 0,1 {r},{r} v{h-2*r} a{r},{r} 0 0,1 {-r},{r} h{-(w-2*r)} a{r},{r} 0 0,1 {-r},{-r} v{-(h-2*r)} a{r},{r} 0 0,1 {r},{-r} z"
# shape = (pathData, fill|None, stroke|None, strokeWidth)
def S(d,fill=None,stroke=None,w=2.2): return (d,fill,stroke,w)
def O(d,fill,w=2.2): return S(d,fill,LINE,w)

bowl_body = "M22,58 h64 c0,20 -12,32 -32,32 c-20,0 -32,-12 -32,-32 z"
def bowl(content=SAGE, dot=None):
    shapes=[O(ell(54,58,32,8),content),
            O(bowl_body,CREAM),
            S("M30,70 q24,10 48,0",None,PEACH,3),
            O(ell(54,92,18,3.5),"#EBDCC8",1.6)]
    shapes.insert(1,S(ell(54,58,28,5.5),None,"#FFFFFF",1.6)) if False else None
    return shapes
ART = {}
ART["ill_bowl"] = (108,108,[
    S(circ(54,54,50),"#00000000",None,0),
    O("M22,56 h64 c0,20 -12,32 -32,32 c-20,0 -32,-12 -32,-32 z",CREAM),
    O(ell(54,56,32,8),SAGE),
    S("M36,53 q6,-3 12,0",None,"#FFFFFF",1.8),
    S("M30,68 q24,10 48,0",None,PEACH,3.2),
    O("M70,32 q8,-10 16,-14",None,2.6),
    O(ell(88,16,6,3.6),HONEY,2),
])
ART["ill_avocado"] = (108,108,[
    O("M54,10 c18,0 30,22 30,44 c0,22 -12,40 -30,40 c-18,0 -30,-18 -30,-40 c0,-22 12,-44 30,-44 z",AVOD),
    O("M54,17 c14,0 24,19 24,38 c0,19 -10,33 -24,33 c-14,0 -24,-14 -24,-33 c0,-19 10,-38 24,-38 z",AVO),
    O(circ(54,62,13),BROWN),
    S("M48,57 q3,-4 7,-4",None,"#FFFFFF",2),
])
ART["ill_carrot"] = (108,108,[
    O("M48,26 q-4,-14 2,-20 q6,8 4,20 z",GREEN2),
    O("M56,26 q2,-16 12,-20 q2,12 -6,22 z",GREEN),
    O("M34,36 c0,-9 9,-13 20,-13 c11,0 20,4 20,13 c0,24 -14,48 -20,64 c-6,-16 -20,-40 -20,-64 z",ORANGE),
    S("M42,42 q5,2 9,0",None,"#D9803C",2),
    S("M56,56 q5,2 9,0",None,"#D9803C",2),
    S("M46,70 q4,2 7,0",None,"#D9803C",2),
    S("M42,34 q4,-4 9,-4",None,"#FFFFFF",2),
])
ART["ill_broccoli"] = (108,108,[
    O("M46,60 h16 l4,34 q-12,6 -24,0 z",GREEN2),
    O(circ(36,44,16),GREEN),O(circ(54,34,19),GREEN),O(circ(72,44,16),GREEN),
    O(ell(54,52,28,12),GREEN),
    S("M44,28 q4,-4 9,-3",None,"#FFFFFF",2),
])
ART["ill_pumpkin"] = (108,108,[
    O("M52,22 q0,-10 8,-14",None,2.8),
    O(ell(34,60,20,30),PUMP),O(ell(74,60,20,30),PUMP),O(ell(54,60,22,33),"#F7C98D"),
    S("M54,28 v64",None,"#D9903F",1.8),
    O("M50,24 q4,-6 10,-1 q-2,6 -10,1 z",GREEN),
])
ART["ill_potato"] = (108,108,[
    O("M26,60 c0,-22 20,-32 40,-28 c20,4 24,26 18,40 c-6,14 -26,20 -42,14 c-10,-4 -16,-12 -16,-26 z",BROWN),
    S(circ(46,56,2),"#8A6446",None,0),S(circ(66,48,2),"#8A6446",None,0),S(circ(60,72,2),"#8A6446",None,0),
    S(circ(40,70,1.6),"#8A6446",None,0),
    S("M40,44 q6,-6 14,-6",None,"#FFFFFF",2),
])
ART["ill_egg"] = (108,108,[
    O("M54,12 c18,0 28,26 28,46 c0,18 -12,32 -28,32 c-16,0 -28,-14 -28,-32 c0,-20 10,-46 28,-46 z",EGG),
    O(circ(54,62,12),YOLK),
    S("M40,36 q4,-8 12,-10",None,"#EBDCC8",2.4),
])
ART["ill_fish"] = (108,108,[
    O("M80,54 l18,-16 v32 z",BLUE),
    O("M12,54 c14,-20 44,-22 68,0 c-24,22 -54,20 -68,0 z",BLUE),
    S("M30,46 q12,8 0,16",None,"#7FA6BE",2.2),
    S("M50,40 q8,14 0,28",None,"#7FA6BE",2.2),
    O(circ(26,52,3),LINE if False else "#FFFFFF",1.6), S(circ(26,52,1.4),LINE,None,0),
])
# HERO: bayi netral + mangkuk + sendok, 160x120
ART["ill_hero_baby"] = (160,120,[
    O("M34,120 c0,-24 18,-38 46,-38 c28,0 46,14 46,38 z",SAGE),
    O(circ(80,52,32),SKIN),
    O("M78,20 q-6,-10 4,-12 q8,2 2,12",None,2.4),
    O(circ(47,54,6),SKIN),O(circ(113,54,6),SKIN),
    O(circ(80,52,32),SKIN),
    S(circ(68,52,3),LINE,None,0),S(circ(92,52,3),LINE,None,0),
    S("M72,64 q8,8 16,0",None,LINE,2.6),
    S(circ(60,62,5),"#F6B8A2",None,0),S(circ(100,62,5),"#F6B8A2",None,0),
    O("M60,88 q20,12 40,0 l8,28 q-28,8 -56,0 z",CREAM),
    S("M70,100 q10,6 20,0",None,PEACH,3),
    O("M112,92 h34 c0,12 -7,18 -17,18 c-10,0 -17,-6 -17,-18 z",CREAM),
    O(ell(129,92,17,4.5),SAGE),
    O("M146,70 l-14,20",None,3),O(ell(148,66,5,7),HONEY,2),
])
ART["ill_empty_bowl"] = (108,108,[
    O("M20,52 h68 c0,22 -13,34 -34,34 c-21,0 -34,-12 -34,-34 z",CREAM),
    O(ell(54,52,34,8),"#F1E8D8"),
    S("M32,64 q22,9 44,0",None,PEACH,3.2),
    O("M78,24 l12,-8",None,2.6),O(ell(94,14,6,3.6),HONEY,2),
    S("M30,30 l4,4 m0,-4 l-4,4",None,SAGE,2.2),S("M24,20 v6 m-3,-3 h6",None,SAGE,2.2),
])

def vd(name,w,h,shapes):
    x=[f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n    android:width="{w}dp"\n    android:height="{h}dp"\n    android:viewportWidth="{w}"\n    android:viewportHeight="{h}">']
    for d,fill,stroke,sw in shapes:
        if fill=="#00000000": continue
        a=[f'android:pathData="{d}"']
        if fill: a.append(f'android:fillColor="{fill}"')
        if stroke and sw>0:
            a += [f'android:strokeColor="{stroke}"',f'android:strokeWidth="{sw}"','android:strokeLineCap="round"','android:strokeLineJoin="round"']
        x.append("    <path\n        "+"\n        ".join(a)+"/>")
    x.append("</vector>"); return "\n".join(x)+"\n"
def svg(w,h,shapes):
    p=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w*3}" height="{h*3}">']
    for d,fill,stroke,sw in shapes:
        if fill=="#00000000": continue
        a=f'd="{d}" fill="{fill or "none"}"'
        if stroke and sw>0: a+=f' stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'
        p.append(f'<path {a}/>')
    p.append("</svg>"); return "".join(p)
os.makedirs(OUT,exist_ok=True); os.makedirs(PREV,exist_ok=True)
html=['<body style="margin:0;background:#FAF8F1;display:flex;flex-wrap:wrap;gap:12px;padding:12px;font:12px sans-serif">']
for n,(w,h,sh) in ART.items():
    open(f"{OUT}/{n}.xml","w").write(vd(n,w,h,sh))
    s=svg(w,h,sh); open(f"{PREV}/{n}.svg","w").write(s)
    html.append(f'<div style="background:#E7EFE6;border-radius:20px;padding:8px;text-align:center">{s}<br>{n}</div>')
open(f"{PREV}/sheet.html","w").write("".join(html))
print(len(ART),"ilustrasi")
