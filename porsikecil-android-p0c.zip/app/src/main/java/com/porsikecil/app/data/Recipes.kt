package com.porsikecil.app.data

import java.time.LocalDate

data class FoodItem(
    val name: String,
    val emoji: String,
    val category: String,
    val minMonths: Int,
    val note: String
)

data class RecipeIngredient(val name: String, val amount: String)

data class Recipe(
    val id: String,
    val title: String,
    val emoji: String,
    val minMonths: Int,
    val texture: String,
    val minutes: Int,
    val tags: List<String>,
    val ingredients: List<RecipeIngredient>,
    val steps: List<String>,
    val tip: String
)

val FoodCategories = listOf(
    "Semua", "Karbohidrat", "Protein hewani", "Protein nabati", "Sayur", "Buah", "Lemak", "Perhatian"
)

val Foods = listOf(
    FoodItem("Beras", "🍚", "Karbohidrat", 6, "Dasar bubur. Masak dengan air hingga sangat lembek."),
    FoodItem("Kentang", "🥔", "Karbohidrat", 6, "Kukus sampai empuk, lalu haluskan."),
    FoodItem("Ubi jalar", "🍠", "Karbohidrat", 6, "Sumber vitamin A. Kukus lalu lumatkan."),
    FoodItem("Oat", "🌾", "Karbohidrat", 6, "Pilih oat polos tanpa gula atau perisa."),
    FoodItem("Hati ayam", "🍗", "Protein hewani", 6, "Kaya zat besi dan vitamin A. Masak matang. Tanyakan ke dokter anak atau ahli gizi soal porsi dan seberapa sering."),
    FoodItem("Daging ayam", "🍗", "Protein hewani", 6, "Rebus atau tim hingga empuk, tanpa kulit."),
    FoodItem("Daging sapi", "🥩", "Protein hewani", 6, "Sumber zat besi. Cincang halus atau blender."),
    FoodItem("Ikan kembung", "🐟", "Protein hewani", 6, "Pastikan bebas duri. Kukus lalu suwir."),
    FoodItem("Ikan salmon", "🐟", "Protein hewani", 6, "Kaya omega-3. Masak matang, periksa duri."),
    FoodItem("Telur", "🥚", "Protein hewani", 6, "Alergen umum. Masak matang sempurna, kenalkan sedikit dulu."),
    FoodItem("Udang", "🦐", "Protein hewani", 8, "Alergen umum. Kenalkan sedikit dan perhatikan reaksi."),
    FoodItem("Tempe", "🍘", "Protein nabati", 6, "Kukus dulu sebelum diolah, lalu haluskan."),
    FoodItem("Tahu", "⬜", "Protein nabati", 6, "Lembut dan mudah dihaluskan. Pilih yang segar."),
    FoodItem("Kacang hijau", "🌱", "Protein nabati", 6, "Rebus sampai sangat lunak, haluskan atau saring."),
    FoodItem("Selai kacang tanah", "🥜", "Protein nabati", 6, "Alergen umum. Encerkan, tanpa gula dan garam. Jangan beri kacang utuh."),
    FoodItem("Wortel", "🥕", "Sayur", 6, "Kukus sampai sangat empuk."),
    FoodItem("Brokoli", "🥦", "Sayur", 6, "Kukus bagian kuntum hingga lembut."),
    FoodItem("Bayam", "🥗", "Sayur", 6, "Sumber zat besi nabati. Rebus sebentar lalu haluskan."),
    FoodItem("Labu kuning", "🎃", "Sayur", 6, "Manis alami dan mudah dilumatkan."),
    FoodItem("Tomat", "🍅", "Sayur", 6, "Kupas kulitnya. Bisa terasa asam, campurkan dengan bahan lain."),
    FoodItem("Buncis", "🌱", "Sayur", 8, "Rebus empuk dan cincang halus."),
    FoodItem("Jamur kancing", "🍄", "Sayur", 8, "Masak matang dan cincang halus."),
    FoodItem("Alpukat", "🥑", "Buah", 6, "Lemak sehat. Lumatkan dengan garpu, tanpa dimasak."),
    FoodItem("Pisang", "🍌", "Buah", 6, "Pilih yang matang. Lumatkan."),
    FoodItem("Pepaya", "🍑", "Buah", 6, "Pilih yang matang dan manis alami."),
    FoodItem("Apel", "🍎", "Buah", 6, "Kukus atau parut halus, jangan diberi potongan mentah."),
    FoodItem("Pir", "🍐", "Buah", 6, "Kukus dan lumatkan."),
    FoodItem("Minyak zaitun", "🌿", "Lemak", 6, "Tambahan lemak sesuai takaran resep."),
    FoodItem("Mentega tanpa garam", "🥄", "Lemak", 6, "Tambahan lemak sesuai takaran resep."),
    FoodItem("Santan", "🥥", "Lemak", 6, "Gunakan santan segar secukupnya, tanpa garam."),
    FoodItem("Madu", "🍯", "Perhatian", 12, "Jangan diberikan sebelum usia 12 bulan (risiko botulisme)."),
    FoodItem("Susu sapi (minuman)", "🥛", "Perhatian", 12, "Belum untuk minuman utama sebelum 12 bulan. Sebagai bahan masak boleh."),
    FoodItem("Garam dan gula", "⚠️", "Perhatian", 12, "Jangan ditambahkan pada makanan bayi. Setelah 12 bulan tetap batasi.")
)

val Recipes = listOf(
    Recipe(
        id = "puree-kentang-wortel",
        title = "Puree Kentang Wortel",
        emoji = "🥔",
        minMonths = 6,
        texture = "Halus",
        minutes = 25,
        tags = listOf("Pertama kali", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Kentang", "60 g"),
            RecipeIngredient("Wortel", "40 g"),
            RecipeIngredient("ASI atau air matang", "3–4 sdm"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kupas kentang dan wortel, potong kecil.",
            "Kukus 15–20 menit sampai sangat empuk.",
            "Haluskan dengan blender atau saringan, tambahkan ASI atau air hingga halus.",
            "Tambahkan minyak zaitun, aduk rata, sajikan hangat."
        ),
        tip = "Kenalkan bahan baru satu per satu dan perhatikan reaksi anak sebelum dicampur."
    ),
    Recipe(
        id = "puree-alpukat-pisang",
        title = "Puree Alpukat Pisang",
        emoji = "🥑",
        minMonths = 6,
        texture = "Halus",
        minutes = 5,
        tags = listOf("Tanpa masak", "Lemak sehat"),
        ingredients = listOf(
            RecipeIngredient("Alpukat matang", "40 g"),
            RecipeIngredient("Pisang matang", "40 g"),
            RecipeIngredient("ASI atau air matang", "1–2 sdm (jika perlu)")
        ),
        steps = listOf(
            "Cuci bersih buah, kupas, buang biji.",
            "Lumatkan dengan garpu sampai halus.",
            "Jika terlalu kental, tambahkan sedikit ASI atau air.",
            "Sajikan segera."
        ),
        tip = "Buat saat akan dimakan karena alpukat cepat berubah warna."
    ),
    Recipe(
        id = "puree-ubi-labu",
        title = "Puree Ubi Labu",
        emoji = "🍠",
        minMonths = 6,
        texture = "Halus",
        minutes = 25,
        tags = listOf("Vitamin A", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Ubi jalar", "50 g"),
            RecipeIngredient("Labu kuning", "40 g"),
            RecipeIngredient("ASI atau air matang", "3–4 sdm"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kupas dan potong ubi serta labu.",
            "Kukus sekitar 15–20 menit sampai empuk.",
            "Haluskan bersama ASI atau air hingga lembut.",
            "Tambahkan minyak zaitun dan aduk."
        ),
        tip = "Rasa manis alaminya biasanya disukai bayi."
    ),
    Recipe(
        id = "bubur-ayam-wortel",
        title = "Bubur Ayam Wortel Saring",
        emoji = "🍲",
        minMonths = 6,
        texture = "Halus (saring)",
        minutes = 40,
        tags = listOf("Protein hewani", "Zat besi"),
        ingredients = listOf(
            RecipeIngredient("Beras", "20 g"),
            RecipeIngredient("Daging ayam", "25 g"),
            RecipeIngredient("Wortel", "30 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Cuci beras, rebus dengan air sampai menjadi bubur lembek.",
            "Tambahkan ayam dan wortel yang sudah dipotong kecil, masak hingga empuk.",
            "Blender lalu saring sampai halus.",
            "Tambahkan minyak zaitun dan sajikan hangat."
        ),
        tip = "Pastikan daging matang sempurna dan tidak ada serat keras."
    ),
    Recipe(
        id = "bubur-hati-bayam",
        title = "Bubur Hati Ayam Bayam",
        emoji = "🥗",
        minMonths = 7,
        texture = "Lumat",
        minutes = 40,
        tags = listOf("Kaya zat besi"),
        ingredients = listOf(
            RecipeIngredient("Beras", "20 g"),
            RecipeIngredient("Hati ayam", "20 g"),
            RecipeIngredient("Bayam", "20 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Mentega tanpa garam", "1 sdt")
        ),
        steps = listOf(
            "Bersihkan hati ayam dari lemak dan urat, rebus hingga matang.",
            "Masak beras dengan air menjadi bubur lembek.",
            "Masukkan bayam dan hati ayam, masak sebentar sampai lunak.",
            "Lumatkan, tambahkan mentega, aduk rata."
        ),
        tip = "Hati kaya zat besi dan vitamin A. Tanyakan ke dokter anak atau ahli gizi soal porsi dan seberapa sering."
    ),
    Recipe(
        id = "bubur-tempe-bayam",
        title = "Bubur Tempe Bayam",
        emoji = "🥣",
        minMonths = 7,
        texture = "Lumat",
        minutes = 35,
        tags = listOf("Nabati", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Beras", "20 g"),
            RecipeIngredient("Tempe", "20 g"),
            RecipeIngredient("Bayam", "20 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kukus tempe 10 menit lalu haluskan.",
            "Masak beras dengan air menjadi bubur lembek.",
            "Masukkan tempe dan bayam, masak hingga lunak.",
            "Lumatkan dan tambahkan minyak zaitun."
        ),
        tip = "Sajikan dengan sumber vitamin C (misalnya buah) agar zat besi nabati lebih mudah diserap."
    ),
    Recipe(
        id = "bubur-ikan-brokoli",
        title = "Bubur Ikan Brokoli",
        emoji = "🐟",
        minMonths = 7,
        texture = "Lumat",
        minutes = 35,
        tags = listOf("Omega-3", "Protein hewani"),
        ingredients = listOf(
            RecipeIngredient("Beras", "25 g"),
            RecipeIngredient("Ikan kembung (fillet)", "25 g"),
            RecipeIngredient("Brokoli", "25 g"),
            RecipeIngredient("Air", "250 ml"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kukus ikan sampai matang, suwir dan periksa teliti dari duri.",
            "Masak beras dengan air menjadi bubur lembek.",
            "Tambahkan brokoli dan ikan, masak hingga lunak.",
            "Lumatkan, beri minyak zaitun."
        ),
        tip = "Periksa duri dua kali. Ikan termasuk alergen umum, perhatikan reaksi pertama kali."
    ),
    Recipe(
        id = "tim-daging-tomat",
        title = "Tim Daging Tomat",
        emoji = "🍅",
        minMonths = 8,
        texture = "Tim kasar",
        minutes = 45,
        tags = listOf("Zat besi", "Protein hewani"),
        ingredients = listOf(
            RecipeIngredient("Beras", "30 g"),
            RecipeIngredient("Daging sapi cincang", "30 g"),
            RecipeIngredient("Tomat (kupas)", "30 g"),
            RecipeIngredient("Wortel", "20 g"),
            RecipeIngredient("Air", "300 ml"),
            RecipeIngredient("Mentega tanpa garam", "1 sdt")
        ),
        steps = listOf(
            "Campur beras, daging, tomat, dan wortel cincang dalam wadah tahan panas.",
            "Tambahkan air, kukus atau tim sekitar 40 menit sampai empuk.",
            "Aduk, haluskan kasar dengan garpu.",
            "Tambahkan mentega dan sajikan hangat."
        ),
        tip = "Tekstur tim kasar melatih bayi mengunyah."
    ),
    Recipe(
        id = "telur-orak-arik",
        title = "Telur Orak-arik dan Nasi Tim",
        emoji = "🥚",
        minMonths = 8,
        texture = "Tim kasar",
        minutes = 15,
        tags = listOf("Mengandung telur", "Cepat"),
        ingredients = listOf(
            RecipeIngredient("Telur", "1 butir"),
            RecipeIngredient("Nasi tim lembek", "50 g"),
            RecipeIngredient("Bayam cincang halus", "15 g"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Kocok telur.",
            "Panaskan minyak zaitun, masak bayam sebentar.",
            "Masukkan telur, aduk sampai matang sempurna dan tidak ada bagian cair.",
            "Sajikan bersama nasi tim lembek."
        ),
        tip = "Telur alergen umum. Kenalkan sedikit dan perhatikan ruam, bengkak, atau muntah."
    ),
    Recipe(
        id = "tim-salmon-labu",
        title = "Tim Salmon Labu",
        emoji = "🐟",
        minMonths = 9,
        texture = "Cincang kasar",
        minutes = 45,
        tags = listOf("Omega-3", "Protein hewani"),
        ingredients = listOf(
            RecipeIngredient("Beras", "35 g"),
            RecipeIngredient("Ikan salmon", "30 g"),
            RecipeIngredient("Labu kuning", "30 g"),
            RecipeIngredient("Brokoli", "20 g"),
            RecipeIngredient("Air", "300 ml"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Campur beras, labu, dan brokoli cincang dengan air, tim hingga empuk.",
            "Kukus salmon sampai matang, suwir kecil dan periksa duri.",
            "Gabungkan, tambahkan minyak zaitun, aduk."
        ),
        tip = "Potong atau cincang kasar, bukan dihaluskan penuh."
    ),
    Recipe(
        id = "perkedel-tahu-wortel",
        title = "Perkedel Tahu Wortel",
        emoji = "🍢",
        minMonths = 9,
        texture = "Finger food lunak",
        minutes = 30,
        tags = listOf("Finger food", "Mengandung telur"),
        ingredients = listOf(
            RecipeIngredient("Tahu", "50 g"),
            RecipeIngredient("Wortel parut", "20 g"),
            RecipeIngredient("Telur", "½ butir"),
            RecipeIngredient("Oat", "10 g")
        ),
        steps = listOf(
            "Hancurkan tahu, campur dengan wortel, telur, dan oat.",
            "Bentuk pipih kecil.",
            "Kukus atau panggang dengan sedikit minyak sampai matang dan lembut.",
            "Dinginkan sebelum disajikan."
        ),
        tip = "Awasi bayi saat makan finger food dan pastikan teksturnya mudah hancur."
    ),
    Recipe(
        id = "pancake-pisang-oat",
        title = "Pancake Pisang Oat",
        emoji = "🥞",
        minMonths = 9,
        texture = "Finger food lunak",
        minutes = 20,
        tags = listOf("Finger food", "Mengandung telur", "Selingan"),
        ingredients = listOf(
            RecipeIngredient("Pisang matang", "50 g"),
            RecipeIngredient("Oat", "20 g"),
            RecipeIngredient("Telur", "½ butir"),
            RecipeIngredient("Mentega tanpa garam", "½ sdt (olesan pan)")
        ),
        steps = listOf(
            "Lumatkan pisang, campur dengan oat dan telur.",
            "Panaskan wajan anti lengket dengan sedikit mentega.",
            "Tuang adonan kecil-kecil, masak dua sisi sampai matang.",
            "Potong memanjang, dinginkan, lalu sajikan."
        ),
        tip = "Tanpa gula atau madu. Manisnya sudah dari pisang."
    ),
    Recipe(
        id = "nasi-tim-ayam-jamur",
        title = "Nasi Tim Ayam Jamur",
        emoji = "🍚",
        minMonths = 12,
        texture = "Makanan keluarga, dipotong kecil",
        minutes = 40,
        tags = listOf("Makanan keluarga"),
        ingredients = listOf(
            RecipeIngredient("Nasi", "70 g"),
            RecipeIngredient("Daging ayam", "40 g"),
            RecipeIngredient("Jamur kancing", "20 g"),
            RecipeIngredient("Wortel", "20 g"),
            RecipeIngredient("Bawang putih", "½ siung"),
            RecipeIngredient("Minyak zaitun", "1 sdt")
        ),
        steps = listOf(
            "Tumis bawang putih dengan sedikit minyak.",
            "Masukkan ayam, jamur, dan wortel yang dipotong kecil, tambahkan sedikit air.",
            "Masak hingga empuk lalu campur dengan nasi.",
            "Tim sebentar agar lembut, sajikan hangat."
        ),
        tip = "Tanpa garam tambahan dan potong kecil agar aman dikunyah."
    ),
    Recipe(
        id = "sup-ayam-sayur",
        title = "Sup Ayam Sayur",
        emoji = "🍜",
        minMonths = 12,
        texture = "Potong kecil",
        minutes = 35,
        tags = listOf("Hangat", "Sayur"),
        ingredients = listOf(
            RecipeIngredient("Daging ayam", "50 g"),
            RecipeIngredient("Kentang", "50 g"),
            RecipeIngredient("Wortel", "30 g"),
            RecipeIngredient("Buncis", "20 g"),
            RecipeIngredient("Air", "300 ml"),
            RecipeIngredient("Bawang putih", "½ siung")
        ),
        steps = listOf(
            "Rebus ayam dengan bawang putih sampai empuk, angkat dan suwir.",
            "Masukkan kentang, wortel, dan buncis ke kaldu, masak hingga lunak.",
            "Kembalikan ayam, masak sebentar.",
            "Sajikan hangat dengan potongan kecil."
        ),
        tip = "Gunakan kaldu rumahan tanpa garam atau penyedap."
    )
)

/** Menu yang disarankan hari ini, bergilir setiap hari sesuai usia. */
fun recipeOfTheDay(months: Int, date: LocalDate): Recipe? {
    if (months < 6) return null
    val pool = Recipes.filter { it.minMonths <= months }
    if (pool.isEmpty()) return null
    return pool[(date.toEpochDay() % pool.size).toInt()]
}
