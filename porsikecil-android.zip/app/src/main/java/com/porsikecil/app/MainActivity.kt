package com.porsikecil.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.porsikecil.app.ui.PorsiKecilApp
import com.porsikecil.app.ui.theme.PorsiKecilTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PorsiKecilTheme {
                PorsiKecilApp()
            }
        }
    }
}
