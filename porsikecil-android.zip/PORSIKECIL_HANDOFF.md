# PorsiKecil 2.0 — HANDOFF (lanjutan bertahap)

Terakhir diperbarui: 3 Nov 2026 · Tahap selesai: **0 (audit), 1 (fondasi), 2 (Beranda)**
Tujuan dokumen: siapa pun (akun/sesi Claude lain) bisa melanjutkan tanpa konteks percakapan sebelumnya.

## 1. Cara melanjutkan (tempel ke sesi baru)

> Baca `PORSIKECIL_HANDOFF.md` di project ini dan `PORSIKECIL_DESIGN_UPGRADE_BRIEF.md`. Lanjutkan **tahap berikutnya yang belum dicentang** di bagian 3. Kerjakan satu tahap saja per sesi, ubah source langsung, jangan menyentuh data/aturan medis, lalu perbarui bagian 3 dan 7 dokumen ini dan berikan ZIP project terbaru. Jangan klaim build sukses kalau tidak dijalankan.

Unggah: ZIP project terbaru (`porsikecil-android-stage2.zip` atau yang lebih baru), brief, dan dua screenshot referensi (opsional).

## 2. Aturan keras (jangan dilanggar)
- Jangan ubah isi `data/AgeAndStage.kt`, `data/Recipes.kt` (bahan, langkah, usia, tekstur, alergen, tip), `data/Planner.kt`, `data/Journal.kt`, atau tes di `src/test`. Itu logika/konten medis; perlu sumber primer, tes, dan review profesional.
- Jangan mengarang sumber, data gizi, atau status "ditinjau dokter".
- Jangan klaim "bebas alergen". Teks yang ada ("tidak terdeteksi dari daftar bahan" + catatan kontaminasi silang) sudah benar; pertahankan.
- Teks keselamatan/penafian boleh ditata ulang tampilannya, tetapi kata-katanya tidak boleh dihilangkan atau diperlunak. Informasi panjang boleh dipindah ke "Lihat panduan", tidak boleh dihapus.
- Stack tetap: Kotlin 1.9.24, AGP 8.5.2, Compose BOM 2024.06.00 (material3 ~1.2.x), Navigation Compose 2.7.7. Hanya `material-icons-core` (tidak ada `icons-extended`). Jangan tambah dependensi tanpa alasan kuat (tidak ada Coil; aset lokal saja).
- Tanpa emoji sebagai ikon utama UI. Jangan tampilkan fitur AI.
- Sumber proyek yang benar: `porsikecil-android-p0f.zip` (lebih baru). Zip di dalam paket `PORSIKECIL_DESIGN_UPGRADE_CLAUDE.zip` adalah versi lama (tidak punya `Ids.kt`, `UserPrefs.kt`, tes alergen); abaikan.

## 3. Status tahap

- [x] **Tahap 0 — Audit** (bagian 4)
- [x] **Tahap 1 — Fondasi**: tokens warna/tipografi/spacing/shape, komponen reusable, 10 ilustrasi lokal, pemetaan resep→ilustrasi. Belum ada layar yang memakainya.
- [x] **Tahap 2 — Beranda** (bagian 5.A): `ui/HomeScreen.kt` baru; belum dikompilasi (lihat bagian 9)
- [x] **Tahap 3 — Resep dan Bahan** (bagian 5.B): selesai di source, belum dibuild (lihat bagian 12)
- [x] **Aset visual resep (18 PNG lokal)** — bagian 14, belum dibuild
- [ ] **Tahap 4a — Planner**, **4b — Edukasi**, **4c — Profil + Onboarding** (5.C–E)
- [ ] **Tahap 5 — QA** (bagian 6)

## 4. Audit ringkas

Struktur: `MainActivity → PorsiKecilApp (NavHost: splash/onboarding/profile_new/profile_edit/main) → MainScreen (Scaffold + NavigationBar 5 tab, state lokal tab/showJournal)`. Penyimpanan: SharedPreferences (`BabyRepository`, `UserPrefsRepository`, `JournalRepository`, `PlannerRepository`). Semua state dibawa di `MainScreen` dan diturunkan ke layar.

Temuan:
1. **Beranda** (`HomeScreen` di `MainScreen.kt`): 7 kartu `SoftCard` bertumpuk, warna berbeda tanpa hierarki; kartu Tahap makan menampilkan frekuensi + sumber + catatan sekaligus (±10 baris); emoji sebagai ikon (👋👶🥣🍽️📝📊⚠️🛡️); tidak ada hero/ilustrasi/thumbnail.
2. **Resep** (`RecipeScreen.kt`): 3 baris chip berurutan + baris alergen + paragraf penafian sebelum daftar → resep baru muncul setelah ±1 layar; kartu resep memakai `r.emoji` (36sp); 🔒 emoji untuk resep belum sesuai usia; tidak ada search di tab Resep (hanya di Bahan); empty state hanya teks.
3. **Edukasi**: masih `ComingSoon` dengan emoji 📚.
4. **Chip** (`UiParts.kt`): tinggi ±36dp (di bawah 48dp), status hanya lewat warna. → sudah diperbaiki di Tahap 1.
5. **Kontras**: `#716F68` (teks sekunder brief) hanya 4,28:1 di atas sage muda dan 4,30:1 di atas peach (<4,5:1). → diganti `#5F5D56` (5,6–6,2:1). Sage `#426B55` di atas cream 5,7:1; putih di atas sage 6,06:1; Ink di atas cream 13,9:1.
6. **Tipografi**: memakai default M3; tidak ada line-height eksplisit. → `Type.kt`.
7. **Onboarding** memakai emoji 84sp; `Planner` memakai emoji dan "⚠️" di teks.
8. **Insets**: app tidak edge-to-edge (status bar opaque); `Scaffold` menangani bottom bar. Jangan aktifkan edge-to-edge kecuali sekalian menambah `statusBarsPadding` di semua layar.
9. **Model**: `Recipe` tidak punya field penyimpanan/sumber. Detail resep versi brief (penyimpanan, sumber klaim kesehatan) **tidak bisa** diisi tanpa konten tervalidasi; jangan diisi sendiri (lihat 5.B).
10. Tidak ada `ModalBottomSheet`/dialog dipakai; `Card(onClick)` sengaja dihindari.

## 5. Rencana file-per-file (tahap berikutnya)

### A. Beranda (Tahap 2)
- **Baru** `ui/HomeScreen.kt`: pindahkan `HomeScreen` dari `MainScreen.kt` (hapus dari sana, import tetap). Tambah parameter `onOpenEducation: () -> Unit`; di `MainScreen.kt` sambungkan ke `tab = 3`.
- Susunan: (1) header sapaan tanpa emoji + nama bayi + tombol profil ringkas; (2) **hero card** (`PkCard` warna `Mint`) dengan `R.drawable.ill_hero_baby`, nama tahap (`stage.title`), `MetaPill` usia (+ usia koreksi bila ada), `MetaPill` tekstur, satu kalimat `stage.note`, tombol **"Lihat panduan"**; (3) kartu **Menu hari ini** dengan `IllustrationTile(recipeArt(menu))`, nama, `MetaPill` tekstur/menit, `allergenSummary(menu)`; jika ada `todayPlan` tampilkan daftar itu; (4) **Ringkasan jurnal** tanpa skor/penilaian (hitungan hari ini + jumlah bahan dicoba); (5) **pintasan** 3 tombol Planner/Jurnal/Edukasi (ikon `DateRange`/`List`/`Info` dari icons-core, target ≥48dp); (6) pengingat keamanan tetap ada (boleh ringkas tampilannya, isi tidak berkurang).
- **"Lihat panduan"**: `ModalBottomSheet` (butuh `@OptIn(ExperimentalMaterial3Api::class)`) berisi persis: `frequency`, `source`, `UnverifiedNote`, dan peringatan prematur. Semua teks lama harus tetap tampil di sini.
- Peringatan prematur (`gestationWeeks != null`) dan `recentAllergy` tetap tampil di Beranda via `InfoNote`, kata-kata tidak diubah.
- Jangan memakai emoji `menu.emoji` di UI baru; pakai `recipeArt`.

### B. Resep dan Bahan (Tahap 3) — `ui/RecipeScreen.kt`
- Tambah search bar di tab Resep (filter `title` saja, `query.take(30)` seperti di Bahan).
- Filter jadi **satu baris horizontal-scroll**: Sesuai usia/Semua usia, Favorit; filter alergen dilipat di bawah satu tombol "Filter alergen" (ekspansi). Penafian kontaminasi silang tetap tampil saat filter alergen dibuka **dan** dalam bentuk `InfoNote` singkat di atas daftar; kalimat penuhnya tidak boleh hilang.
- `RecipeCard` baru: `IllustrationTile(recipeArt(r))` kiri, judul, `MetaPill` "Mulai N bulan", tekstur, "±N menit", `allergenSummary(r)`; favorit `IconButton` (48dp) dengan contentDescription yang sudah ada. Resep belum sesuai usia: label teks "Belum sesuai usia" (bukan 🔒).
- Empty state: `EmptyState(R.drawable.ill_empty_bowl, ...)` menggantikan teks "Tidak ada resep…" dan pesan favorit kosong.
- `RecipeDetail`: ilustrasi besar di atas, ganti emoji judul bagian (⚠️🥕🍳💡) dengan judul teks; pertahankan semua bagian dan teks keselamatan.
- **Jangan** menambah bagian "penyimpanan"/"sumber" dengan konten karangan. Jika ingin, tambahkan field nullable di `Recipe` (mis. `storage: String? = null`) hanya sebagai struktur, dan tampilkan bagian itu hanya bila terisi; isi konten harus dari sumber yang diverifikasi pengguna.
- `FoodRow` (Bahan): ganti `f.emoji` dengan tile ilustrasi generik/kategori (belum ada ilustrasi per bahan; tambah di `tools/gen_art.py` bila perlu, mis. wortel/brokoli sudah ada).

### C. Planner (Tahap 4a) — `ui/PlannerScreen.kt` (405 baris, **audit dulu**)
Kalender mingguan, timeline fleksibel, kartu resep kecil dengan thumbnail (`recipeArt`), daftar belanja mudah ditemukan (tombol/tab jelas). Bahasa tidak memaksa ("saran", bukan "wajib"). Hapus emoji di teks. Logika `data/Planner.kt` jangan diubah.

### D. Edukasi (Tahap 4b) — baru `ui/EducationScreen.kt`, ganti `ComingSoon`
Hub editorial: kategori (`ChipRow`), kartu artikel dengan ilustrasi, waktu baca, tanggal pembaruan. Buat struktur `SourceRef(type: Pedoman resmi|Jurnal|Editorial, institution, title, year, url, reviewedOn)` dan `SourceCard`. **Jangan memasukkan entri sumber/artikel yang belum diberikan pengguna.** Satu-satunya sumber yang sudah ada di app: WHO GHO, Minimum meal frequency (6–23 bulan), diakses 3 Nov 2026 (dipakai di `AgeAndStage.kt`). Jika konten belum tersedia, tampilkan kerangka + keadaan kosong jujur, dan minta pengguna daftar sumber yang valid. Jangan menulis "diverifikasi dokter".

### E. Profil dan Onboarding (Tahap 4c)
`ProfileTab` di `MainScreen.kt` → `PkCard`, avatar ilustrasi, bagian preferensi/jurnal/privasi (teks privasi yang ada dipertahankan), ekspor/hapus data **hanya bila** fungsinya benar-benar dibuat (jangan tampilkan tombol palsu). Grafik pertumbuhan: **jangan** dibuat (standar belum divalidasi). `Onboarding.kt`: ganti emoji 84sp dengan ilustrasi.

## 6. QA (Tahap 5)
- `./gradlew testDebugUnitTest assembleDebug` (+ `assembleRelease` bila ada keystore) — **belum pernah dijalankan** untuk versi ini.
- Uji: layar kecil (320dp lebar), font scale 1.3–2.0, TalkBack (ilustrasi bermakna punya contentDescription; dekoratif `null`), orientasi, scroll bersarang (hindari `verticalScroll` di dalam `verticalScroll`; di `RecipeScreen` daftar memakai `Modifier.weight(1f)` + scroll sendiri), back button (sheet/detail/jurnal), target sentuh ≥48dp.
- Pastikan 3 tes unit lama tetap hijau tanpa diubah.

## 7. Yang sudah dikerjakan (Tahap 1) dan belum diverifikasi

File baru/berubah:
- `ui/theme/Theme.kt` (diubah): palet brief; nama lama dipertahankan agar layar lama tetap compile; `Soft` = `#5F5D56` (alasan kontras); radius kartu 24dp, medium 16, small 12; memakai `PorsiTypography`.
- `ui/theme/Type.kt` (baru): skala tipografi sp + line-height.
- `ui/theme/Dimens.kt` (baru): `Space` (4/8/12/16/24/32, screen 20, touch 48).
- `ui/UiParts.kt` (diubah): `SelectChip` ≥48dp + tanda centang + `selectable` (role RadioButton); API `SelectChip/ChipRow/UnverifiedNote` tidak berubah.
- `ui/DesignSystem.kt` (baru): `PkCard`, `IllustrationTile`, `MetaPill`, `SectionHeader` (heading semantics), `InfoNote`, `EmptyState`.
- `ui/RecipeArt.kt` (baru): `recipeArt(recipe)` → ilustrasi + tint + deskripsi. Murni UI, `Recipe` tidak diubah.
- `res/drawable/ill_*.xml` (baru, 10 VectorDrawable, total ±48 KB): `ill_bowl, ill_avocado, ill_carrot, ill_broccoli, ill_pumpkin, ill_potato, ill_egg, ill_fish, ill_hero_baby, ill_empty_bowl`. Gaya: bentuk bulat, outline hangat `#5A4A3F`, palet terbatas. Pratinjau: `docs/art-preview.png`.
- `tools/gen_art.py` (baru): sumber ilustrasi. Edit lalu jalankan `python3 tools/gen_art.py app/src/main/res/drawable docs/preview` untuk membuat ulang XML.
- Belum ada ilustrasi: bayam, tahu/tempe, ayam, daging, tomat, jamur. Resep terkait sementara memakai `ill_bowl`.

Status verifikasi (jujur):
- XML drawable: lolos parse XML dan sudah dirender sebagai SVG untuk pemeriksaan visual. **Belum** dirender oleh Android (aapt/Studio).
- Kotlin: **belum dikompilasi** (sandbox tanpa Android SDK/Gradle/internet). Risiko yang perlu dicek pertama saat build: import di `DesignSystem.kt`/`UiParts.kt`, `Modifier.fillMaxSize(fraction)`, `Icons.Filled.Check/Info` (ada di icons-core), `Card` + `clickable`.
- Tes unit: tidak dijalankan.
- Belum ada layar yang memakai komponen baru, jadi tampilan aplikasi hanya berubah pada warna, bentuk, tipografi, dan chip.

## 8. Catatan keputusan
- Kontras `#716F68` ditolak (lihat 4.5). Jika ingin kembali ke nilai brief, pakai hanya di atas putih/cream (4,73–5,03:1) dan jangan di atas Mint/Peach.
- `Honey` (`#F4D98B`) hanya untuk ilustrasi/penanda; teks di atasnya harus Ink (10,6:1).
- Ilustrasi sengaja vector drawable (bukan Canvas Compose) supaya ringan, mudah diperiksa, dan kecil kemungkinan error compile.

## 9. Tahap 2 — Beranda (selesai di source, belum dibuild)

Berubah:
- `ui/HomeScreen.kt` (baru): `HomeScreen` dipindah dari `MainScreen.kt` dengan parameter tambahan `onOpenEducation`. Susunan: sapaan + `IconButton` profil (48dp, contentDescription "Ubah profil"); `InfoNote` prematur bila `gestationWeeks != null`; hero `PkCard(Mint)` (`ill_hero_baby` dekoratif, `stage.title`, `MetaPill` usia dan tekstur, kalimat usia koreksi utuh, `stage.note`, tombol "Lihat panduan"); kartu Menu hari ini (daftar `todayPlan` dengan thumbnail dari `recipeArt`, atau saran `recipeOfTheDay` dengan `IllustrationTile` + `MetaPill` + `allergenSummary`, atau `EmptyState`); Ringkasan jurnal (dua angka, tanpa skor; `InfoNote` dugaan reaksi 7 hari); tiga pintasan Planner/Jurnal/Edukasi; Pengingat keamanan (4 poin + penafian, kata-kata sama).
- "Lihat panduan" = `ModalBottomSheet` berisi tahap, tekstur, `Jadwal: frequency`, `note`, `source`, `UnverifiedNote`, usia koreksi, peringatan prematur. Frekuensi/sumber/UnverifiedNote tidak lagi tampil langsung di Beranda, hanya di sheet.
- `ui/MainScreen.kt`: `HomeScreen` lama dihapus, import tak terpakai dibersihkan, `onOpenEducation = { tab = 3 }`. `SoftCard` dan `ProfileTab` tetap (dipakai sampai Tahap 4c).
- Emoji pada Beranda dihapus (👋👶🥣🍽️📝📊⚠️🛡️ dan `menu.emoji`). Kartu "Catat makanan" digantikan pintasan Jurnal. Kartu "Usia" terpisah dilebur ke hero.
- Teks baru yang ditambahkan (bukan konten medis): "Halo,", "Tahap makan", "Saran", "Lihat panduan", "Panduan tahap makan", "Tutup", judul empty state ("Belum ada saran menu", "Belum waktunya MPASI"), label pintasan. Tinjau bila perlu.

Tidak disentuh: `data/*`, tes, `Recipes.kt`.

Yang harus dicek pertama saat build (belum pernah dikompilasi/dijalankan):
1. `FlowRow` (`@ExperimentalLayoutApi`, foundation 1.6.x) dan `ModalBottomSheet` + `rememberModalBottomSheetState(skipPartiallyExpanded = true)` (`@ExperimentalMaterial3Api`) — sudah diberi `@OptIn`.
2. `IconButtonDefaults.iconButtonColors(containerColor = ...)`, `Modifier.clickable(role = ...)`.
3. Visual: hero di lebar 320dp dan font scale 2.0 (teks di samping gambar 88dp, tiga pintasan sebaris bisa terlalu sempit; bila ya, ubah pintasan jadi `Column`).
4. Sheet di layar kecil: konten memakai `verticalScroll` sendiri.

Berikutnya: Tahap 4a (Planner).

## 12. Tahap 3 — Resep dan Bahan (selesai di source, belum dibuild)

Berubah: `ui/RecipeScreen.kt`, `ui/RecipeArt.kt` (tambah `foodArt`). `data/*`, tes, `Recipes.kt` tidak disentuh.
- Tab Resep: search "Cari resep" (judul saja, `take(30)`); satu baris chip scroll (Sesuai usia / Semua usia / Favorit); tombol "Filter alergen" melipat chip alergen. Kalimat penuh kontaminasi silang tampil saat filter dibuka; `InfoNote` singkat tampil saat tertutup.
- `RecipeCard`: `IllustrationTile(recipeArt)`, judul, `MetaPill` (Mulai N bulan, tekstur, menit), `allergenSummary`, label teks "Belum sesuai usia" (ganti 🔒), tombol favorit 48dp.
- Empty state memakai `EmptyState(ill_empty_bowl)` untuk favorit kosong, hasil kosong, dan bahan tidak ditemukan.
- `RecipeDetail`: ilustrasi 160dp, judul bagian tanpa emoji, semua teks keselamatan tetap. Tidak ada bagian penyimpanan/sumber baru (sesuai 5.B).
- `FoodRow`: tile ilustrasi lewat `foodArt`; bahan tanpa ilustrasi memakai mangkuk. Label "Perhatian" dan "belum sesuai usia" berupa teks.
- Teks baru (bukan konten medis): "Cari resep", "Filter alergen", "Tutup filter alergen", "Belum ada favorit", "Tidak ada resep yang cocok", "Belum sesuai usia".

Cek pertama saat build: `FlowRow` + `@OptIn(ExperimentalLayoutApi)` di `RecipeCard`, import `Search` (icons-core), tata letak kartu di 320dp dan font scale 2.0. Perubahan filter: filter usia sekarang tiga chip dalam satu baris (perilaku sama).

## 13. Paket "Premium Visual" (3 Nov 2026) — ikon custom + bersih emoji (belum dibuild)

Sumber: `PORSIKECIL_PREMIUM_VISUAL_CLAUDE.zip` (brief + 3 screenshot lama). ZIP source di dalamnya **usang** (sebelum Tahap 1-3); yang dipakai adalah project ini.
- **Keluarga ikon** (12 VectorDrawable, grid 24, stroke 1.8, ujung bulat, outline; diwarnai lewat `tint`): `ic_home, ic_recipes, ic_planner, ic_education, ic_profile, ic_heart, ic_heart_filled, ic_search, ic_filter, ic_check, ic_info, ic_journal, ic_back`. Dipakai di bottom nav, Beranda (profil, pintasan, info), Resep (search, favorit, filter), `SelectChip`, `InfoNote`, dan `BackButton` baru (`DesignSystem.kt`, menggantikan "← Kembali").
- Emoji dihapus dari semua kode UI: Onboarding/splash (kini ilustrasi lokal), `ComingSoon` (parameter jadi `@DrawableRes art`), Planner (teks kartu resep, "⚠️"), Profil ("👶"). Field `emoji` di `data/Recipes.kt` tetap ada tetapi tidak lagi dipakai UI (data tidak disentuh).
- Kartu resep dipadatkan: baris keterangan alergen hanya tampil bila resep punya alergen terdeteksi. Pernyataan "tidak terdeteksi dari daftar bahan" + catatan kontaminasi silang tetap ada di detail resep dan catatan filter. Ini perubahan tampilan, bukan data.
- **Foto makanan: tidak ada.** Tidak ada foto berlisensi yang bisa diperoleh di sini (sandbox tanpa internet, dan tidak boleh mengarang lisensi). Fallback: ilustrasi vector lokal (`ill_*`), bukan foto hasil resep. Aset semuanya buatan sendiri lewat `tools/gen_art.py`; tidak ada aset eksternal.
- Belum: loading/error state (app tidak punya pemuatan jaringan, jadi belum ada yang perlu ditampilkan), ilustrasi bayam/tahu/ayam/tomat/jamur, screenshot emulator, build/test.
- Cek pertama saat build: overload `Icon(painter=..., tint=...)`, ikon outline kecil (hati/centang) terbaca di 16-18dp, `ill_*` di onboarding 120dp.

## 14. Aset visual resep premium (3 Nov 2026) — 18 PNG lokal (belum dibuild)

Sumber: `PORSIKECIL_PREMIUM_ASSETS.zip`. Berisi **ilustrasi vektor bergaya editorial** (dirender ke PNG 1024x768), **bukan foto makanan asli**. Semua lokal; tidak ada URL/library baru.

Berubah:
- `res/drawable-nodpi/recipe_*.png` (baru, 18 file, total ±1,6 MB). Nama resource unik, tidak bentrok dengan `ill_*`.
- `ui/RecipeArt.kt`: `recipeArt(r)` kini memetakan **18 `recipe.id` -> PNG** (cocok per id, bukan urutan). `RecipeArtSpec` dan `foodArt()` tidak diubah. `else` tetap `ill_bowl`. Tambah `RecipeArtSpec.isFullScene()` (false hanya untuk `ill_bowl`).
- `ui/DesignSystem.kt`: komponen baru `RecipeImage(art, modifier, aspectRatio, shape)`. PNG resep adalah adegan penuh 4:3 dengan bahan pendamping di tepi kiri/kanan, jadi **tidak** dimasukkan ke `IllustrationTile` persegi (akan mengecil ke 80% atau terpotong). `IllustrationTile` tetap dipakai untuk bahan (`foodArt`).
- `ui/RecipeScreen.kt`: kartu resep memakai `RecipeImage` lebar 96dp (80dp bila layar < 360dp), rasio 4:3 (tanpa potong). Detail resep memakai lebar penuh, rasio 3:2 (`ContentScale.Crop` hanya memangkas ±5,5% ruang kosong atas/bawah; sudah dicek terhadap dua aset, bahan samping dan dasar mangkuk tidak terpotong), sudut `shapes.large`.
- `ui/HomeScreen.kt`: thumbnail Menu hari ini (96dp, dan 72dp untuk daftar `todayPlan`) memakai `RecipeImage`.
- `docs/premium-assets/`: SVG sumber, manifest, contact sheet, README paket (untuk edit/ekspor ulang).
- Tidak disentuh: `data/*`, `src/test`, `Recipes.kt`, navigasi, favorit/pencarian/filter, penyimpanan. Field `emoji` di model tidak dipakai UI.

Terverifikasi (statik): 18 id di `Recipes.kt` = 18 id di mapping, semua resource ada, tidak ada nama resource ganda, `data/` dan `src/test` identik dengan versi sebelumnya.
Belum diverifikasi: kompilasi, tes unit, `assembleDebug`, tampilan di emulator/perangkat (tidak ada Gradle wrapper/Android SDK/internet di sandbox).
Cek pertama saat build: `RecipeImage` (`aspectRatio` + `clip` + `ContentScale.Crop`), lebar kolom teks kartu resep di 320dp dan font scale 2.0 (thumbnail 80dp), ukuran APK (+±1,6 MB).
Catatan: placeholder `ill_bowl` kini hanya muncul untuk id resep baru yang belum punya gambar.

## 15. Foto resep batch 2 (3 Nov 2026) — 5 foto AI, 3 resep baru (belum dibuild)

Sumber: `139141`–`139145.png` (1448x1086, 4:3), dikonversi ke WebP 1024x768 (q82, ±110–150 KB per file).
- `139141` -> `tahu-labu-lembut`, `139142` -> `bubur-hati-bayam`: cocok dengan resep yang sudah ada. PNG ilustrasi lama dengan nama sama dihapus, diganti `.webp`.
- `139143`, `139144`, `139145` **tidak cocok** dengan resep mana pun (daging sapi + brokoli, salmon + wortel, telur + brokoli). Atas **permintaan eksplisit pemilik proyek** ("samakan menu dengan foto"), 3 resep BARU ditambahkan ke `data/Recipes.kt` (resep lama tidak diubah): `puree-daging-brokoli` (7 bln, Lumat), `puree-salmon-wortel` (7 bln, Lumat), `puree-telur-brokoli` (8 bln, Lumat). Disisipkan agar urutan `minMonths` tetap naik (tes `recipesAreOrderedByMinimumAge`).
- Isi resep baru disalin dari pola resep yang sudah ada (usia/tekstur setara hati-bayam, ikan-brokoli, telur-kukus). **Bahan, takaran, usia, dan langkah belum ditinjau ahli gizi/dokter anak** dan harus ditinjau sebelum rilis. Alergen terdeteksi otomatis dari nama bahan (Ikan, Telur).
- `ui/RecipeArt.kt`: tambah 3 mapping id -> WebP, komentar diperbarui (sebagian gambar foto AI).
- `data/` lain dan `src/test` tidak diubah. Tes yang ada tidak mengunci jumlah resep (hanya id unik, urutan usia, jumlah resep "Gaya Jepang" = 4; resep baru tidak memakai tag itu).
- Foto bergaya AI: catat alat dan lisensi komersialnya; jangan sebut "foto asli" di UI/Play Store.
- Batch 1 (`139134`–`139138`) juga sudah dimasukkan (WebP 1024x768, q82): `puree-kentang-wortel`, `puree-alpukat-pisang`, `puree-ubi-labu`, `bubur-ayam-wortel`, `okayu-bayi`. Semua cocok dengan bahan di `Recipes.kt` (dicek per id). `139135` (1229x1280, hampir persegi) di-crop manual ke 4:3 (y 190–1112): alpukat belah + biji, pisang, irisan pisang tetap terlihat; bagian atas alpukat utuh dan sedikit irisan pisang paling bawah terpotong. Bila ingin utuh, minta ulang foto 4:3.
- Belum diverifikasi: kompilasi, tes unit, tampilan di perangkat (tidak ada Gradle/Android SDK di sandbox).

## 16. Foto resep batch 3 (4 Nov 2026) — 5 foto AI (belum dibuild)

Sumber: 5 PNG 1448x1086 (4:3), dikonversi ke WebP 1024x768 (q82, 93–142 KB per file). PNG ilustrasi lama dengan nama sama dihapus. Tidak ada resep baru, `Recipes.kt`, `RecipeArt.kt`, dan tes tidak diubah (nama resource sama).
- 1 -> `bubur-tempe-bayam` (puree hijau, tempe, bayam). Cocok.
- 2 -> `bubur-ikan-brokoli` (puree hijau muda, fillet ikan putih, brokoli). Cocok.
- 3 -> `bubur-ikan-bayam` (bubur putih-hijau, mangkuk nasi, bayam, ikan putih). Cocok.
- 4 -> `tim-daging-tomat` (tomat, daging giling, peterseli). Cocok.
- 5 -> `telur-orak-arik` (nasi, telur orak-arik, potongan wortel, daun bawang). **Perbedaan kecil**: di `Recipes.kt` bahannya telur, nasi tim, **bayam**, minyak zaitun; foto menampilkan wortel + daun bawang, tanpa bayam. Data resep sengaja tidak diubah. Opsi: terima sebagai ilustrasi penyajian, minta foto ulang dengan bayam, atau (atas permintaan pemilik) sesuaikan bahan.
- Status: **15 dari 21 resep berfoto AI**. Masih ilustrasi PNG lama (6): `telur-kukus-lembut`, `tim-salmon-labu`, `perkedel-tahu-wortel`, `pancake-pisang-oat`, `nasi-tim-ayam-jamur`, `sup-ayam-sayur`.
- Belum diverifikasi: kompilasi, tes unit, tampilan di perangkat.

## 17. Foto resep batch 4 (4 Nov 2026) — 5 foto AI (belum dibuild)

Sumber: 5 PNG 1448x1086 (4:3) -> WebP 1024x768 (q82, 86-129 KB). PNG lama dengan nama sama dihapus. `Recipes.kt`, `RecipeArt.kt`, tes tidak diubah.
- `telur-kukus-lembut`: cocok (telur kukus + wortel). Tambahan di foto: daun bawang (tidak ada di bahan).
- `tim-salmon-labu`: cocok (salmon, labu, nasi). Brokoli di daftar bahan tidak terlihat; hiasan peterseli tidak ada di bahan.
- `perkedel-tahu-wortel`: cocok (tahu, wortel). Oat tidak terlihat; ada hiasan peterseli. Tampilan goreng/kecokelatan; cara masak resep tidak diubah.
- `pancake-pisang-oat`: cocok (pisang, oat, pancake).
- `nasi-tim-ayam-jamur`: cocok (nasi, ayam, jamur, wortel).
- Perbedaan kecil di atas hanya hiasan/penyajian; data resep sengaja tidak diubah.
- Status: **20 dari 21 resep berfoto AI**. Tersisa ilustrasi PNG lama (1): `sup-ayam-sayur`.
- Belum diverifikasi: kompilasi, tes unit, tampilan di perangkat.
